import React from 'react';
import type { ScoreState, Player, GameMode } from '../utils/gameLogic';
import type { Translations } from '../utils/translations';

interface ScoreBoardProps {
  scores: ScoreState;
  currentTurn: Player;
  gameMode: GameMode;
  t: Translations;
  theme: 'neon' | 'cyberDark' | 'paper';
  isGameOver: boolean;
}

export const ScoreBoard: React.FC<ScoreBoardProps> = ({
  scores,
  currentTurn,
  gameMode,
  t,
  theme,
  isGameOver,
}) => {
  const isXActive = !isGameOver && currentTurn === 'X';
  const isOActive = !isGameOver && currentTurn === 'O';
  const isNeon = theme === 'neon' || theme === 'cyberDark';

  // Card background and border styles
  const cardBase = isNeon
    ? 'bg-[#181335]/90 border border-indigo-900/60 text-white shadow-lg backdrop-blur-md'
    : 'bg-white/80 border border-stone-200 text-stone-900 shadow-xs';

  const activeX = isNeon
    ? 'ring-2 ring-red-500/80 shadow-[0_0_18px_rgba(255,23,68,0.4)]'
    : 'ring-2 ring-stone-900 bg-stone-50';

  const activeO = isNeon
    ? 'ring-2 ring-cyan-400/80 shadow-[0_0_18px_rgba(0,229,255,0.4)]'
    : 'ring-2 ring-rose-600 bg-rose-50/50';

  return (
    <div className="w-full max-w-[440px] mx-auto grid grid-cols-3 gap-2.5 sm:gap-3 text-center select-none">
      {/* Player X Tile (Red Neon) */}
      <div
        className={`p-3 rounded-xl transition-all duration-200 ${cardBase} ${
          isXActive ? activeX : 'opacity-80'
        }`}
      >
        <div className="flex items-center justify-center gap-1.5 mb-0.5">
          <span
            className="font-black text-lg leading-none"
            style={{
              color: '#ffffff',
              textShadow: isNeon ? '0 0 8px #ff1744, 0 0 16px #ff1744' : undefined,
            }}
          >
            ✕
          </span>
          <span className="text-[11px] sm:text-xs font-semibold tracking-wide truncate">
            {t.playerX}
          </span>
        </div>
        <div
          className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums leading-tight"
          style={{
            textShadow: isNeon && isXActive ? '0 0 12px rgba(255,23,68,0.7)' : undefined,
          }}
        >
          {scores.xWins}
        </div>
        <div className="text-[10px] sm:text-[11px] opacity-75 mt-0.5">
          {isXActive ? (
            <span className="font-bold text-red-400">{t.turnX}</span>
          ) : (
            <span>{t.round}</span>
          )}
        </div>
      </div>

      {/* Draws / Total Games */}
      <div className={`p-3 rounded-xl opacity-80 ${cardBase}`}>
        <div className="flex items-center justify-center gap-1 mb-0.5">
          <span className="text-[11px] sm:text-xs font-semibold tracking-wide">{t.draws}</span>
        </div>
        <div className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums leading-tight">
          {scores.draws}
        </div>
        <div className="text-[10px] sm:text-[11px] opacity-75 mt-0.5">
          {scores.streak !== 0 && (
            <span className="font-semibold text-amber-400">
              {t.streak}: {scores.streak > 0 ? `X+${scores.streak}` : `O+${Math.abs(scores.streak)}`}
            </span>
          )}
          {scores.streak === 0 && (
            <span>
              {scores.totalGames} {t.totalGames}
            </span>
          )}
        </div>
      </div>

      {/* Player O / AI Tile (Blue Neon) */}
      <div
        className={`p-3 rounded-xl transition-all duration-200 ${cardBase} ${
          isOActive ? activeO : 'opacity-80'
        }`}
      >
        <div className="flex items-center justify-center gap-1.5 mb-0.5">
          <span
            className="font-black text-lg leading-none"
            style={{
              color: '#ffffff',
              textShadow: isNeon ? '0 0 8px #00e5ff, 0 0 16px #00e5ff' : undefined,
            }}
          >
            ◯
          </span>
          <span className="text-[11px] sm:text-xs font-semibold tracking-wide truncate">
            {gameMode === 'vs-ai' ? t.aiPlayer : t.playerO}
          </span>
        </div>
        <div
          className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums leading-tight"
          style={{
            textShadow: isNeon && isOActive ? '0 0 12px rgba(0,229,255,0.7)' : undefined,
          }}
        >
          {scores.oWins}
        </div>
        <div className="text-[10px] sm:text-[11px] opacity-75 mt-0.5">
          {isOActive ? (
            <span className="font-bold text-cyan-400">{t.turnO}</span>
          ) : (
            <span>{t.round}</span>
          )}
        </div>
      </div>
    </div>
  );
};
