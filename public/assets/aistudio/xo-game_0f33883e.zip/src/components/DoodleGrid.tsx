import React, { useState } from 'react';
import type { CellValue, Player, WinResult, GridDimension } from '../utils/gameLogic';
import { NeonMark } from './NeonMark';

interface DoodleGridProps {
  board: CellValue[];
  size: GridDimension;
  turn: Player;
  winnerInfo: WinResult | null;
  onCellClick: (index: number) => void;
  disabled?: boolean;
  theme?: 'neon' | 'cyberDark' | 'paper';
}

export const DoodleGrid: React.FC<DoodleGridProps> = ({
  board,
  size,
  turn,
  winnerInfo,
  onCellClick,
  disabled = false,
  theme = 'neon',
}) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  // Neon theme tile background & borders
  const isNeon = theme === 'neon' || theme === 'cyberDark';

  return (
    <div className="relative w-full max-w-[430px] aspect-square mx-auto p-2 sm:p-3 select-none">
      {/* Outer Glow Halo Frame for Neon Mode */}
      {isNeon && (
        <div
          className="absolute inset-0 rounded-2xl pointer-events-none"
          style={{
            boxShadow: '0 0 35px rgba(0, 112, 243, 0.2), inset 0 0 20px rgba(255, 23, 68, 0.1)',
            border: '2px solid rgba(255, 255, 255, 0.15)',
          }}
        />
      )}

      {/* Grid Container */}
      <div
        className={`relative z-10 w-full h-full grid p-1.5 rounded-xl ${
          isNeon
            ? 'bg-[#ffffff] shadow-2xl gap-1.5 sm:gap-2' // White crisp grid separators between tiles!
            : 'bg-stone-300 gap-1 rounded-lg'
        }`}
        style={{
          gridTemplateColumns: `repeat(${size}, minmax(0, 1fr))`,
          gridTemplateRows: `repeat(${size}, minmax(0, 1fr))`,
          backgroundColor: isNeon ? '#ffffff' : undefined,
        }}
      >
        {board.map((cell, idx) => {
          const isWinningCell = winnerInfo?.line.includes(idx);
          const isEmpty = cell === null;
          const showGhost = isEmpty && hoveredIndex === idx && !disabled && !winnerInfo;

          // Cell styling based on reference image: dark indigo/purple tiles
          const tileClass = isNeon
            ? 'bg-[#181335] hover:bg-[#201a47] active:bg-[#282159]'
            : 'bg-white hover:bg-stone-50';

          return (
            <button
              key={idx}
              type="button"
              disabled={disabled || !isEmpty || Boolean(winnerInfo)}
              onClick={() => onCellClick(idx)}
              onMouseEnter={() => setHoveredIndex(idx)}
              onMouseLeave={() => setHoveredIndex(null)}
              className={`relative flex items-center justify-center w-full h-full rounded-sm sm:rounded-md transition-all duration-150 overflow-hidden focus:outline-none ${tileClass} ${
                isEmpty && !disabled && !winnerInfo ? 'cursor-pointer active:scale-96' : 'cursor-default'
              } ${isWinningCell ? 'ring-2 ring-white/80' : ''}`}
              aria-label={`Grid cell ${idx + 1}, currently ${cell || 'empty'}`}
            >
              {/* Subtle inner tile depth gradient */}
              {isNeon && (
                <div
                  className="absolute inset-0 pointer-events-none opacity-40"
                  style={{
                    background: 'radial-gradient(circle at 50% 30%, rgba(255,255,255,0.06) 0%, transparent 70%)',
                  }}
                />
              )}

              {/* Placed Mark or Ghost Preview */}
              {cell ? (
                <NeonMark
                  type={cell}
                  isWinning={isWinningCell}
                  theme={theme}
                  seed={idx}
                />
              ) : showGhost ? (
                <NeonMark
                  type={turn}
                  isGhost={true}
                  theme={theme}
                  seed={idx}
                />
              ) : null}
            </button>
          );
        })}
      </div>
    </div>
  );
};
