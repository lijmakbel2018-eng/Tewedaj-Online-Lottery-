export type Language = 'en' | 'am';

export interface Translations {
  gameTitle: string;
  gameSubtitle: string;
  vsAi: string;
  passAndPlay: string;
  gridSize: string;
  difficulty: string;
  easy: string;
  medium: string;
  impossible: string;
  easyDesc: string;
  mediumDesc: string;
  impossibleDesc: string;
  turnX: string;
  turnO: string;
  yourTurn: string;
  aiThinking: string;
  xWins: string;
  oWins: string;
  youWin: string;
  aiWins: string;
  drawGame: string;
  playAgain: string;
  undo: string;
  resetScores: string;
  replay: string;
  viewReference: string;
  soundOn: string;
  soundOff: string;
  timerMode: string;
  theme: string;
  neonTheme: string;
  cyberDarkTheme: string;
  paperTheme: string;
  streak: string;
  totalGames: string;
  playerX: string;
  playerO: string;
  aiPlayer: string;
  draws: string;
  round: string;
  moveHistory: string;
  step: string;
  close: string;
  rulesTitle: string;
  rulesBody: string;
  originalArtwork: string;
  originalArtworkDesc: string;
  timerLeft: string;
  timeOut: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    gameTitle: 'Neon Glow Tic-Tac-Toe',
    gameSubtitle: '3D glowing neon arcade XO game with laser win strikes and smart AI',
    vsAi: 'Play vs AI',
    passAndPlay: '2 Players (Pass & Play)',
    gridSize: 'Grid Size',
    difficulty: 'AI Difficulty',
    easy: 'Casual',
    medium: 'Tactical',
    impossible: 'Unbeatable (Minimax)',
    easyDesc: 'Relaxed and playful',
    mediumDesc: 'Solid defense and counters',
    impossibleDesc: 'Mathematically flawless; best is a draw',
    turnX: "Player X's Turn",
    turnO: "Player O's Turn",
    yourTurn: 'Your Turn (X - Neon Red)',
    aiThinking: 'AI is thinking...',
    xWins: 'Player X Wins!',
    oWins: 'Player O Wins!',
    youWin: 'You Won! Radiant Victory!',
    aiWins: 'AI Wins! Better luck next time',
    drawGame: "It's a Stalemate!",
    playAgain: 'Play Again',
    undo: 'Undo',
    resetScores: 'Reset Scores',
    replay: 'Replay Match',
    viewReference: 'View Reference Image',
    soundOn: 'Audio: On',
    soundOff: 'Audio: Muted',
    timerMode: 'Blitz Timer (5s)',
    theme: 'Theme',
    neonTheme: 'Neon Arcade (Active)',
    cyberDarkTheme: 'Midnight Cyber',
    paperTheme: 'Sketch Paper',
    streak: 'Streak',
    totalGames: 'Total Games',
    playerX: 'Player X (Neon Red)',
    playerO: 'Player O (Neon Blue)',
    aiPlayer: 'AI Bot (Neon Blue)',
    draws: 'Draws',
    round: 'Round',
    moveHistory: 'Move History',
    step: 'Step',
    close: 'Close',
    rulesTitle: 'Game Rules',
    rulesBody: 'Take turns dropping glowing neon tokens onto the dark grid. Complete a horizontal, vertical, or diagonal line to unleash a laser beam strike!',
    originalArtwork: 'Your Uploaded Reference',
    originalArtworkDesc: '3D embossed white symbols with luminous red and cyan-blue neon halos and vertical laser beam.',
    timerLeft: 'Time Left',
    timeOut: "Time's up! Turn passed.",
  },
  am: {
    gameTitle: 'የኒዮን ቲክ-ታክ-ቶ (XO) ጨዋታ',
    gameSubtitle: 'በደማቅ የኒዮን መብራት እና ሌዘር የተዋበ ዘመናዊ የቲክ-ታክ-ቶ ጨዋታ',
    vsAi: 'ከኮምፒውተር (AI) ጋር',
    passAndPlay: '2 ተጫዋቾች (በአንድ ስክሪን)',
    gridSize: 'የሜዳው መጠን',
    difficulty: 'የAI ደረጃ',
    easy: 'ቀላል',
    medium: 'መካከለኛ',
    impossible: 'የማይሸነፍ (Unbeatable)',
    easyDesc: 'ለጀማሪ እና ለመዝናናት',
    mediumDesc: 'ጥሩ ጥንቃቄ የሚያደርግ',
    impossibleDesc: 'በሂሳብ ስሌት ፍጹም የሆነ፤ ምርጡ ውጤት አቻ ነው',
    turnX: 'የተጫዋች X ተራ',
    turnO: 'የተጫዋች O ተራ',
    yourTurn: 'የእርስዎ ተራ (X - ቀይ ኒዮን)',
    aiThinking: 'ኮምፒውተሩ እያሰበ ነው...',
    xWins: 'ተጫዋች X አሸነፈ!',
    oWins: 'ተጫዋች O አሸነፈ!',
    youWin: 'እንኳን ደስ አለዎት! በድምቀት አሸንፈዋል!',
    aiWins: 'ኮምፒውተሩ አሸነፈ! በሚቀጥለው ይሞክሩ',
    drawGame: 'አቻ ወጣ!',
    playAgain: 'እንደገና ጀምር',
    undo: 'ወደኋላ መልስ',
    resetScores: 'ውጤት አድስ',
    replay: 'ጨዋታውን በድጋሚ እይ',
    viewReference: 'የላኩትን ምስል እይ',
    soundOn: 'ድምፅ፡ በርቷል',
    soundOff: 'ድምፅ፡ ጠፍቷል',
    timerMode: 'ፈጣን ሰዓት (5 ሰከንድ)',
    theme: 'ገጽታ (Theme)',
    neonTheme: 'ደማቅ ኒዮን (የተመረጠው)',
    cyberDarkTheme: 'ጥቁር ሳይበር',
    paperTheme: 'የወረቀት ንድፍ',
    streak: 'ተከታታይ ድል',
    totalGames: 'ጠቅላላ ጨዋታዎች',
    playerX: 'ተጫዋች X (ቀይ ኒዮን)',
    playerO: 'ተጫዋች O (ሰማያዊ ኒዮን)',
    aiPlayer: 'ኮምፒውተር (ሰማያዊ ኒዮን)',
    draws: 'አቻ',
    round: 'ዙር',
    moveHistory: 'የተደረጉ እርምጃዎች',
    step: 'ደረጃ',
    close: 'ዝጋ',
    rulesTitle: 'የጨዋታው ደንቦች',
    rulesBody: 'በየተራ ምልክትዎን በኒዮን ሜዳው ላይ ያሳርፉ። አግድም፣ ቁልቁል ወይም በሰያፍ ሶስት (3) በተከታታይ ያገኘ በደማቅ ሌዘር ብርሃን ያሸንፋል!',
    originalArtwork: 'የላኩት አዲሱ ምስል',
    originalArtworkDesc: 'ከላኩት ምስል ጋር በትክክል የተገናዘበ 3D ነጭ ምልክቶች ከቀይና ሰማያዊ የኒዮን መብራት ጋር።',
    timerLeft: 'የቀረ ሰዓት',
    timeOut: 'ሰዓት አልቋል! ተራው አለፈ።',
  },
};
