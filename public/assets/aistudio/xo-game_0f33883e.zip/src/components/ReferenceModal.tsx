import React from 'react';
import { X, Check } from 'lucide-react';
import type { Translations } from '../utils/translations';

interface ReferenceModalProps {
  isOpen: boolean;
  onClose: () => void;
  t: Translations;
  theme: 'neon' | 'cyberDark' | 'paper';
}

export const ReferenceModal: React.FC<ReferenceModalProps> = ({
  isOpen,
  onClose,
  t,
  theme,
}) => {
  if (!isOpen) return null;

  const isNeon = theme === 'neon' || theme === 'cyberDark';
  const modalBg = isNeon
    ? 'bg-[#130f2b] text-white border border-indigo-800/80'
    : 'bg-white text-stone-900 border border-stone-200';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className={`relative w-full max-w-md rounded-2xl p-6 shadow-2xl ${modalBg}`}>
        <div className="flex items-center justify-between pb-3 border-b border-indigo-900/50">
          <div>
            <h3 className="text-base font-bold">{t.originalArtwork}</h3>
            <p className="text-xs opacity-75">{t.originalArtworkDesc}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-4 flex flex-col items-center">
          <div className="relative rounded-xl overflow-hidden border border-indigo-500/40 max-w-[280px] shadow-[0_0_25px_rgba(0,112,243,0.3)]">
            <img
              src="/public/assets/aistudio/unnamed_ad7cebf5.png"
              alt="Uploaded 3D Neon Glow Tic-Tac-Toe reference"
              referrerPolicy="no-referrer"
              className="w-full h-auto object-contain"
            />
          </div>
          <p className="text-xs opacity-75 mt-3 text-center px-4">
            Recreated with 3D embossed white symbols, fiery red neon glow for X, electric cyan-blue neon glow for O, and bright laser strike beams!
          </p>
        </div>

        <div className="pt-2 border-t border-indigo-900/50 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 flex items-center gap-1.5 text-xs font-semibold rounded-lg bg-white text-slate-950 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
