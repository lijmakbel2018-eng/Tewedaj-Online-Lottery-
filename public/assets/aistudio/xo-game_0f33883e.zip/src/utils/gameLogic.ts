export type Player = 'X' | 'O';
export type CellValue = Player | null;
export type GameMode = 'vs-ai' | 'pass-and-play';
export type AIDifficulty = 'easy' | 'medium' | 'impossible';
export type GridDimension = 3 | 4 | 5;

export interface WinResult {
  winner: Player;
  line: number[];
  direction: 'horizontal' | 'vertical' | 'diagonal-main' | 'diagonal-anti';
  rowOrColIndex?: number;
}

export interface MoveRecord {
  step: number;
  cellIndex: number;
  player: Player;
  boardSnapshot: CellValue[];
}

export interface ScoreState {
  xWins: number;
  oWins: number;
  draws: number;
  streak: number; // positive for X, negative for O
  totalGames: number;
}

/**
 * Checks for a win condition based on the grid dimension and win target.
 */
export function checkWin(board: CellValue[], size: GridDimension = 3): WinResult | null {
  const winLength = size === 3 ? 3 : 4; // 3-in-a-row for 3x3; 4-in-a-row for 4x4 and 5x5

  // 1. Check Horizontal Rows
  for (let r = 0; r < size; r++) {
    for (let c = 0; c <= size - winLength; c++) {
      const first = board[r * size + c];
      if (!first) continue;
      let matched = true;
      const line: number[] = [r * size + c];
      for (let k = 1; k < winLength; k++) {
        const next = board[r * size + c + k];
        if (next !== first) {
          matched = false;
          break;
        }
        line.push(r * size + c + k);
      }
      if (matched) {
        return {
          winner: first,
          line,
          direction: 'horizontal',
          rowOrColIndex: r,
        };
      }
    }
  }

  // 2. Check Vertical Columns
  for (let c = 0; c < size; c++) {
    for (let r = 0; r <= size - winLength; r++) {
      const first = board[r * size + c];
      if (!first) continue;
      let matched = true;
      const line: number[] = [r * size + c];
      for (let k = 1; k < winLength; k++) {
        const next = board[(r + k) * size + c];
        if (next !== first) {
          matched = false;
          break;
        }
        line.push((r + k) * size + c);
      }
      if (matched) {
        return {
          winner: first,
          line,
          direction: 'vertical',
          rowOrColIndex: c,
        };
      }
    }
  }

  // 3. Check Main Diagonals (top-left to bottom-right)
  for (let r = 0; r <= size - winLength; r++) {
    for (let c = 0; c <= size - winLength; c++) {
      const first = board[r * size + c];
      if (!first) continue;
      let matched = true;
      const line: number[] = [r * size + c];
      for (let k = 1; k < winLength; k++) {
        const next = board[(r + k) * size + (c + k)];
        if (next !== first) {
          matched = false;
          break;
        }
        line.push((r + k) * size + (c + k));
      }
      if (matched) {
        return {
          winner: first,
          line,
          direction: 'diagonal-main',
        };
      }
    }
  }

  // 4. Check Anti-Diagonals (top-right to bottom-left)
  for (let r = 0; r <= size - winLength; r++) {
    for (let c = winLength - 1; c < size; c++) {
      const first = board[r * size + c];
      if (!first) continue;
      let matched = true;
      const line: number[] = [r * size + c];
      for (let k = 1; k < winLength; k++) {
        const next = board[(r + k) * size + (c - k)];
        if (next !== first) {
          matched = false;
          break;
        }
        line.push((r + k) * size + (c - k));
      }
      if (matched) {
        return {
          winner: first,
          line,
          direction: 'diagonal-anti',
        };
      }
    }
  }

  return null;
}

/**
 * Checks if the board is completely full without a winner
 */
export function isBoardFull(board: CellValue[]): boolean {
  return board.every((cell) => cell !== null);
}

/**
 * Returns available empty cell indexes
 */
export function getAvailableMoves(board: CellValue[]): number[] {
  const moves: number[] = [];
  for (let i = 0; i < board.length; i++) {
    if (board[i] === null) {
      moves.push(i);
    }
  }
  return moves;
}

/**
 * Minimax algorithm for standard 3x3 grid (provably unbeatable)
 */
function minimax3x3(
  board: CellValue[],
  depth: number,
  isMaximizing: boolean,
  alpha: number,
  beta: number
): { score: number; move?: number } {
  const win = checkWin(board, 3);
  if (win) {
    // If AI ('O') wins, score positive. If Player ('X') wins, score negative.
    return { score: win.winner === 'O' ? 10 - depth : depth - 10 };
  }
  if (isBoardFull(board)) {
    return { score: 0 };
  }

  const available = getAvailableMoves(board);

  if (isMaximizing) {
    let maxScore = -Infinity;
    let bestMove = available[0];

    for (const move of available) {
      board[move] = 'O';
      const result = minimax3x3(board, depth + 1, false, alpha, beta);
      board[move] = null;

      if (result.score > maxScore) {
        maxScore = result.score;
        bestMove = move;
      }
      alpha = Math.max(alpha, maxScore);
      if (beta <= alpha) break;
    }
    return { score: maxScore, move: bestMove };
  } else {
    let minScore = Infinity;
    let bestMove = available[0];

    for (const move of available) {
      board[move] = 'X';
      const result = minimax3x3(board, depth + 1, true, alpha, beta);
      board[move] = null;

      if (result.score < minScore) {
        minScore = result.score;
        bestMove = move;
      }
      beta = Math.min(beta, minScore);
      if (beta <= alpha) break;
    }
    return { score: minScore, move: bestMove };
  }
}

/**
 * Heuristic evaluation for larger grids (4x4, 5x5)
 */
function evaluateHeuristic(board: CellValue[], size: GridDimension): number {
  const win = checkWin(board, size);
  if (win) {
    return win.winner === 'O' ? 1000 : -1000;
  }
  // Center bias
  let score = 0;
  const center = (size - 1) / 2;
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const idx = r * size + c;
      const cell = board[idx];
      if (cell) {
        const distFromCenter = Math.abs(r - center) + Math.abs(c - center);
        const weight = 5 - distFromCenter;
        score += cell === 'O' ? weight : -weight;
      }
    }
  }
  return score;
}

/**
 * Depth-limited Minimax with Alpha-Beta for larger grids
 */
function minimaxHeuristic(
  board: CellValue[],
  depth: number,
  maxDepth: number,
  isMaximizing: boolean,
  size: GridDimension,
  alpha: number,
  beta: number
): { score: number; move?: number } {
  const win = checkWin(board, size);
  if (win) {
    return { score: win.winner === 'O' ? 1000 - depth * 10 : depth * 10 - 1000 };
  }
  if (isBoardFull(board) || depth >= maxDepth) {
    return { score: evaluateHeuristic(board, size) };
  }

  const available = getAvailableMoves(board);
  // Sort moves prioritizing center
  const center = (size - 1) / 2;
  available.sort((a, b) => {
    const ra = Math.floor(a / size), ca = a % size;
    const rb = Math.floor(b / size), cb = b % size;
    const da = Math.abs(ra - center) + Math.abs(ca - center);
    const db = Math.abs(rb - center) + Math.abs(cb - center);
    return da - db;
  });

  if (isMaximizing) {
    let maxScore = -Infinity;
    let bestMove = available[0];

    for (const move of available) {
      board[move] = 'O';
      const result = minimaxHeuristic(board, depth + 1, maxDepth, false, size, alpha, beta);
      board[move] = null;

      if (result.score > maxScore) {
        maxScore = result.score;
        bestMove = move;
      }
      alpha = Math.max(alpha, maxScore);
      if (beta <= alpha) break;
    }
    return { score: maxScore, move: bestMove };
  } else {
    let minScore = Infinity;
    let bestMove = available[0];

    for (const move of available) {
      board[move] = 'X';
      const result = minimaxHeuristic(board, depth + 1, maxDepth, true, size, alpha, beta);
      board[move] = null;

      if (result.score < minScore) {
        minScore = result.score;
        bestMove = move;
      }
      beta = Math.min(beta, minScore);
      if (beta <= alpha) break;
    }
    return { score: minScore, move: bestMove };
  }
}

/**
 * Gets the AI's move according to selected difficulty
 */
export function getAIMove(board: CellValue[], difficulty: AIDifficulty, size: GridDimension = 3): number {
  const available = getAvailableMoves(board);
  if (available.length === 0) return -1;

  // Check immediate winning move for AI ('O')
  for (const move of available) {
    board[move] = 'O';
    const win = checkWin(board, size);
    board[move] = null;
    if (win && win.winner === 'O') {
      return move;
    }
  }

  // Check immediate blocking move against player ('X')
  for (const move of available) {
    board[move] = 'X';
    const win = checkWin(board, size);
    board[move] = null;
    if (win && win.winner === 'X') {
      // In easy mode, 35% chance to miss the block
      if (difficulty === 'easy' && Math.random() < 0.35) {
        continue;
      }
      return move;
    }
  }

  // Easy mode: mostly random
  if (difficulty === 'easy') {
    return available[Math.floor(Math.random() * available.length)];
  }

  // Medium mode: 65% optimal, 35% random center/corner
  if (difficulty === 'medium') {
    if (Math.random() > 0.65) {
      // Pick center if free
      const centerIdx = Math.floor(board.length / 2);
      if (board[centerIdx] === null) return centerIdx;
      // Pick a random available
      return available[Math.floor(Math.random() * available.length)];
    }
  }

  // Impossible mode: Full minimax
  if (size === 3) {
    const result = minimax3x3([...board], 0, true, -Infinity, Infinity);
    return result.move !== undefined ? result.move : available[0];
  } else {
    const maxDepth = size === 4 ? 4 : 3;
    const result = minimaxHeuristic([...board], 0, maxDepth, true, size, -Infinity, Infinity);
    return result.move !== undefined ? result.move : available[0];
  }
}
