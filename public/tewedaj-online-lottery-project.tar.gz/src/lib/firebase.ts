import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// Web App Firebase configuration provided for Tewedaj Online Lottery
export const firebaseConfig = {
  apiKey: "AIzaSyCTdi7gEKxuitfXoOyi2PNZ5KntKNqGhPE",
  authDomain: "tewedaj-online-lottery.firebaseapp.com",
  projectId: "tewedaj-online-lottery",
  storageBucket: "tewedaj-online-lottery.firebasestorage.app",
  messagingSenderId: "120710535914",
  appId: "1:120710535914:web:cc29dc90850bd9e7d25593",
  measurementId: "G-2WL0DVD0CE"
};

export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const db = getFirestore(app);
