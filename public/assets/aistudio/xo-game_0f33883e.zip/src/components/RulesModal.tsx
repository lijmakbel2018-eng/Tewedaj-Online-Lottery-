import React from 'react';
import { X, Check, HelpCircle } from 'lucide-react';
import type { Translations } from '../utils/translations';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  t: Translations;
  theme: 'neon' | 'cyberDark' | 'paper';
}

export const RulesModal: React.FC<RulesModalProps> = ({
  isOpen,
  onClose,
  t,
  theme,
}) => {
  if (!isOpen) return null;

  const isNeon = theme === 'neon' || theme === 'cyberDark';
  const modalBg = isNeon
    ? 'bg-[#130f2b] text-white border border-indigo-800/80'
    : 'bg-white text-stone-900 border border-stone-200';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className={`relative w-full max-w-md rounded-2xl p-6 shadow-2xl ${modalBg}`}>
        <div className="flex items-center justify-between pb-3 border-b border-indigo-900/50">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold">{t.rulesTitle}</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-4 space-y-3 text-xs leading-relaxed opacity-90">
          <p>{t.rulesBody}</p>

          <div className="p-3 rounded-lg border border-indigo-900/60 bg-indigo-950/40 space-y-2">
            <div className="font-semibold text-white">⚡ Neon Features:</div>
            <ul className="list-disc pl-4 space-y-1 opacity-85">
              <li>
                <strong>3D Glowing Marks:</strong> Player X projects fiery red neon light; Player O projects electric cyan-blue neon light.
              </li>
              <li>
                <strong>Laser Beam Win:</strong> Align 3 in a row to trigger the blinding white laser strike beam!
              </li>
              <li>
                <strong>AI Modes:</strong> Casual for relaxed play, Tactical for sharp challenges, and Unbeatable (Minimax) for an impossible mathematical duel.
              </li>
              <li>
                <strong>Blitz Timer:</strong> Optional 5-second quick-turn challenge for fast-paced arcade action.
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-2 border-t border-indigo-900/50 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 flex items-center gap-1.5 text-xs font-semibold rounded-lg bg-white text-slate-950 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
