import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, 
  Send, 
  Sparkles, 
  ShieldCheck, 
  Users, 
  Clock,
  X,
  Reply,
  Trash2,
} from 'lucide-react';
import { Language, UserProfile } from '../../types/lottery';

interface GroupChatViewProps {
  user: UserProfile;
  lang: Language;
  triggerHaptic?: (style: 'light' | 'medium' | 'heavy') => void;
  playNotificationSound?: (type: 'click' | 'win' | 'alert') => void;
}

interface ChatMsg {
  id: string;
  senderName: string;
  senderPhone: string;
  text: string;
  timestamp: string;
  isAdmin?: boolean;
  replyTo?: {
    id: string;
    senderName: string;
    text: string;
  };
}

export const GroupChatView: React.FC<GroupChatViewProps> = ({
  user,
  lang,
  triggerHaptic,
  playNotificationSound,
}) => {
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [inputText, setInputText] = useState('');
  const [sending, setSending] = useState(false);
  const [replyTo, setReplyTo] = useState<ChatMsg | null>(null);
  const [highlightedId, setHighlightedId] = useState<string | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const messageRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const fetchMessages = async () => {
    try {
      const res = await fetch('/api/group/chat/messages');
      if (!res.ok) return;
      const data = await res.json();
      if (data.ok && Array.isArray(data.messages)) {
        if (data.messages.length > 0) {
          setMessages(data.messages);
        }
      }
    } catch {}
  };

  useEffect(() => {
    fetchMessages();
    const interval = setInterval(fetchMessages, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const scrollToMessage = (targetId: string) => {
    const el = messageRefs.current[targetId];
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setHighlightedId(targetId);
      triggerHaptic?.('light');
      setTimeout(() => setHighlightedId(null), 1500);
    }
  };

  const cleanUserPhone = user.phone ? user.phone.replace(/\D/g, '') : '';
  const isOwner = cleanUserPhone.includes('910961881') || user.telegramUsername?.toLowerCase() === 'lij_makbel';

  const handleDeleteMessage = async (msgId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm(lang === 'am' ? 'ይህንን መልዕክት መሰረዝ ይፈልጋሉ?' : 'Delete this message?')) {
      return;
    }
    triggerHaptic?.('medium');
    playNotificationSound?.('click');
    try {
      const res = await fetch('/api/group/chat/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messageId: msgId,
          adminPhone: user.phone,
          adminUsername: user.telegramUsername,
        }),
      });
      const data = await res.json();
      if (data.ok && Array.isArray(data.messages)) {
        setMessages(data.messages);
      } else {
        setMessages(prev => prev.filter(m => m.id !== msgId));
      }
    } catch (err) {
      console.error('Delete chat message error', err);
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    const txt = inputText.trim();
    if (!txt || sending) return;

    setSending(true);
    triggerHaptic?.('medium');
    playNotificationSound?.('click');

    const cleanPhone = user.phone ? user.phone.replace(/\D/g, '') : '';
    const isAdmin = cleanPhone.includes('910961881') || user.telegramUsername?.toLowerCase() === 'lij_makbel';

    const replyPayload = replyTo ? {
      id: replyTo.id,
      senderName: replyTo.senderPhone?.includes('0910961881') ? '👑 Owner' : (replyTo.senderPhone ? `(${replyTo.senderPhone.slice(-4)})` : replyTo.senderName),
      text: replyTo.text,
    } : undefined;

    try {
      const res = await fetch('/api/group/chat/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderName: user.phone ? `(${user.phone.slice(-4)})` : (user.fullName || 'ደንበኛ'),
          senderPhone: user.phone || '0910961881',
          text: txt,
          isAdmin,
          replyTo: replyPayload,
        }),
      });
      const data = await res.json();
      if (data.ok && data.messages) {
        setMessages(data.messages);
        setInputText('');
        setReplyTo(null);
      }
    } catch (err) {
      console.error('[Chat Send Error]', err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-120px)] bg-slate-950 text-slate-100 overflow-hidden rounded-2xl border border-slate-800/80 shadow-xl">
      {/* Group Header */}
      <div className="bg-slate-900 border-b border-slate-800 p-3.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-500 to-emerald-500 flex items-center justify-center text-slate-950 font-black shadow-lg">
            <Users className="w-5 h-5 text-slate-950 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-black text-blue-500 text-sm">
                Tewedaj Online Lottery
              </h3>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>
          </div>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-slate-950 to-slate-900/40">
        {messages.map((msg) => {
          const isMe = msg.senderPhone === user.phone || msg.senderName === user.fullName;
          const isHighlighted = highlightedId === msg.id;

          return (
            <div
              key={msg.id}
              ref={(el) => {
                messageRefs.current[msg.id] = el;
              }}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} w-full space-y-1 transition duration-300 ${
                isHighlighted ? 'scale-[1.02] filter drop-shadow-[0_0_12px_rgba(56,189,248,0.5)]' : ''
              }`}
            >
              <div className="flex items-center gap-1.5 px-1 text-[10px] text-slate-400">
                <span className={`font-bold ${msg.isAdmin ? 'text-amber-400 font-black' : 'text-slate-300'}`}>
                  {msg.senderPhone.includes('0910961881') ? '👑 Owner' : (msg.senderPhone ? `(${msg.senderPhone.slice(-4)})` : msg.senderName)}
                </span>
                <span>•</span>
                <span>{new Date(msg.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</span>
                {isOwner && (
                  <button
                    type="button"
                    onClick={(e) => handleDeleteMessage(msg.id, e)}
                    className="ml-1 p-0.5 text-rose-400 hover:text-rose-300 hover:bg-rose-950/60 rounded transition active:scale-90"
                    title={lang === 'am' ? 'መልዕክቱን ሰርዝ' : 'Delete message'}
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Message Bubble */}
              <div 
                className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs sm:text-sm leading-relaxed shadow-md text-left transition relative group cursor-pointer ${
                  msg.isAdmin 
                    ? 'bg-gradient-to-r from-amber-500/20 via-yellow-500/20 to-amber-500/10 border border-amber-500/40 text-amber-100 font-medium'
                    : isMe 
                      ? 'bg-emerald-500 text-slate-950 font-medium rounded-tr-sm shadow-emerald-500/10' 
                      : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-sm'
                }`}
                onClick={() => {
                  setReplyTo(msg);
                  triggerHaptic?.('light');
                }}
              >
                {/* Telegram-style Quoted Reply Box */}
                {msg.replyTo && (
                  <div
                    onClick={(e) => {
                      e.stopPropagation();
                      if (msg.replyTo?.id) {
                        scrollToMessage(msg.replyTo.id);
                      }
                    }}
                    className={`mb-2 pl-2.5 pr-2 py-1 rounded-xl text-left border-l-4 cursor-pointer transition select-none ${
                      isMe
                        ? 'bg-slate-950/20 border-slate-950 text-slate-900 hover:bg-slate-950/30'
                        : msg.isAdmin
                          ? 'bg-amber-950/40 border-amber-400 text-amber-200 hover:bg-amber-950/60'
                          : 'bg-slate-800/80 border-sky-400 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className={`text-[10px] font-black leading-tight flex items-center gap-1 ${
                      isMe ? 'text-slate-950 font-black' : msg.isAdmin ? 'text-amber-300' : 'text-sky-400'
                    }`}>
                      <Reply className="w-2.5 h-2.5 inline" />
                      <span>{msg.replyTo.senderName}</span>
                    </div>
                    <div className="text-[11px] truncate opacity-90 max-w-[240px]">
                      {msg.replyTo.text}
                    </div>
                  </div>
                )}

                {/* Main Message Text */}
                <div className="break-words">
                  {msg.text}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={chatEndRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={handleSend} className="bg-slate-900 border-t border-slate-800 p-3 shrink-0 flex flex-col gap-2">
        {/* Telegram-style Reply Preview Bar */}
        {replyTo && (
          <div className="bg-slate-800/90 border border-slate-700/80 rounded-xl px-3 py-1.5 flex items-center justify-between gap-2 text-xs animate-in slide-in-from-bottom-2">
            <div className="flex items-center gap-2 min-w-0 border-l-2 border-sky-400 pl-2">
              <Reply className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <div className="min-w-0 text-left">
                <div className="text-[10px] font-bold text-sky-400 truncate">
                  Replying to {replyTo.senderPhone?.includes('0910961881') ? '👑 Owner' : (replyTo.senderPhone ? `(${replyTo.senderPhone.slice(-4)})` : replyTo.senderName)}
                </div>
                <div className="text-[11px] text-slate-300 truncate max-w-[220px]">
                  {replyTo.text}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setReplyTo(null)}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700/60 transition"
              title="ምላሽ ሰርዝ"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        <div className="flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder=""
            className="flex-1 bg-slate-950 border border-slate-800 focus:border-sky-500 rounded-xl px-3.5 py-2.5 text-white text-xs sm:text-sm focus:outline-none focus:ring-1 focus:ring-sky-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || sending}
            className="bg-sky-500 hover:bg-sky-400 active:scale-95 disabled:opacity-50 text-slate-950 font-black px-4 py-2.5 rounded-xl transition flex items-center justify-center shadow-lg shadow-sky-500/20 cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};
