import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import type { Player } from '../utils/gameLogic';

interface DoodleMarkProps {
  type: Player;
  isWinning?: boolean;
  isGhost?: boolean;
  theme?: 'paper' | 'chalkboard' | 'blueprint';
  seed?: number;
}

export const DoodleMark: React.FC<DoodleMarkProps> = ({
  type,
  isWinning = false,
  isGhost = false,
  theme = 'paper',
  seed = 0,
}) => {
  // Generate slight deterministic variations based on seed
  const variation = useMemo(() => {
    const rot = ((seed * 17) % 14) - 7; // -7 to +7 deg rotation
    const wobble1 = ((seed * 7) % 6) - 3;
    const wobble2 = ((seed * 11) % 6) - 3;
    const wobble3 = ((seed * 13) % 8) - 4;
    return { rot, wobble1, wobble2, wobble3 };
  }, [seed]);

  // Color selection based on theme and type
  const strokeColor = useMemo(() => {
    if (isGhost) {
      if (theme === 'chalkboard') return 'rgba(255, 255, 255, 0.25)';
      if (theme === 'blueprint') return 'rgba(255, 255, 255, 0.25)';
      return type === 'X' ? 'rgba(30, 41, 59, 0.2)' : 'rgba(225, 29, 72, 0.25)';
    }

    if (type === 'X') {
      if (theme === 'chalkboard') return '#f1f5f9'; // crisp chalk white
      if (theme === 'blueprint') return '#ffffff';
      return '#1c1917'; // rich brush ink black
    } else {
      // 'O' is vivid red across all themes just like the user's reference!
      if (theme === 'chalkboard') return '#ff385c';
      if (theme === 'blueprint') return '#ff6b6b';
      return '#e11d48'; // vibrant organic brush red
    }
  }, [type, isGhost, theme]);

  if (type === 'X') {
    // Two brush strokes crossing each other
    return (
      <motion.svg
        initial={isGhost ? false : { scale: 0.6, opacity: 0 }}
        animate={{ scale: 1, opacity: isGhost ? 0.4 : 1 }}
        transition={{ type: 'spring', stiffness: 380, damping: 22 }}
        viewBox="0 0 100 100"
        className={`w-full h-full p-2 select-none pointer-events-none drop-shadow-sm ${
          isWinning ? 'animate-bounce' : ''
        }`}
        style={{ transform: `rotate(${variation.rot}deg)` }}
      >
        <defs>
          <filter id={`rough-x-${seed}`} x="-10%" y="-10%" width="120%" height="120%">
            <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="2" result="noise" />
            <feDisplacementMap in="SourceGraphic" in2="noise" scale="3" xChannelSelector="R" yChannelSelector="G" />
          </filter>
        </defs>

        <g filter={`url(#rough-x-${seed})`}>
          {/* First diagonal stroke (top-left to bottom-right) */}
          <motion.path
            d={`M ${18 + variation.wobble1} ${20} Q ${50 + variation.wobble2} ${50 + variation.wobble1} ${82 + variation.wobble3} ${80}`}
            fill="none"
            stroke={strokeColor}
            strokeWidth="11"
            strokeLinecap="round"
            strokeLinejoin="round"
            initial={isGhost ? false : { pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.16, ease: 'easeOut' }}
          />
          {/* Secondary micro-bristle stroke for organic ink fullness */}
          <path
            d={`M ${21 + variation.wobble2} ${22} Q ${51} ${49} ${79} ${78}`}
            fill="none"
            stroke={strokeColor}
            strokeWidth="4"
            opacity="0.85"
            strokeLinecap="round"
          />

          {/* Second diagonal stroke (top-right to bottom-left) */}
          <motion.path
            d={`M ${80 + variation.wobble2} ${18} Q ${50 + variation.wobble3} ${50 + variation.wobble2} ${20 + variation.wobble1} ${82}`}
            fill="none"
            stroke={strokeColor}
            strokeWidth="11"
            strokeLinecap="round"
            strokeLinejoin="round"
            initial={isGhost ? false : { pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.18, delay: isGhost ? 0 : 0.08, ease: 'easeOut' }}
          />
          {/* Secondary bristle line */}
          <path
            d={`M ${78} ${21} Q ${49} ${51} ${22} ${80}`}
            fill="none"
            stroke={strokeColor}
            strokeWidth="4"
            opacity="0.85"
            strokeLinecap="round"
          />
        </g>
      </motion.svg>
    );
  }

  // 'O' mark: organic brush circle with open overlap, mirroring the reference image
  return (
    <motion.svg
      initial={isGhost ? false : { scale: 0.6, opacity: 0 }}
      animate={{ scale: 1, opacity: isGhost ? 0.4 : 1 }}
      transition={{ type: 'spring', stiffness: 360, damping: 20 }}
      viewBox="0 0 100 100"
      className={`w-full h-full p-2 select-none pointer-events-none drop-shadow-sm ${
        isWinning ? 'animate-bounce' : ''
      }`}
      style={{ transform: `rotate(${variation.rot * 1.5}deg)` }}
    >
      <defs>
        <filter id={`rough-o-${seed}`} x="-10%" y="-10%" width="120%" height="120%">
          <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="2" result="noise" />
          <feDisplacementMap in="SourceGraphic" in2="noise" scale="3" xChannelSelector="R" yChannelSelector="G" />
        </filter>
      </defs>

      <g filter={`url(#rough-o-${seed})`}>
        {/* Main circular loop starting from top and looping around with brush overlap */}
        <motion.path
          d={`M ${52 + variation.wobble1} ${16}
              C ${22 + variation.wobble2} ${18}, ${14} ${42 + variation.wobble3}, ${16 + variation.wobble1} ${64}
              C ${18} ${84}, ${42 + variation.wobble2} ${86}, ${68 + variation.wobble3} ${82}
              C ${84} ${78}, ${88} ${56}, ${84 + variation.wobble2} ${34}
              C ${82} ${18}, ${60 + variation.wobble1} ${16}, ${46 + variation.wobble3} ${22}`}
          fill="none"
          stroke={strokeColor}
          strokeWidth="11"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={isGhost ? false : { pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.24, ease: 'easeOut' }}
        />
        {/* Subtle inner bristle arc */}
        <path
          d={`M ${50} ${19}
              C ${25} ${22}, ${18} ${44}, ${20} ${63}
              C ${22} ${81}, ${44} ${83}, ${66} ${80}
              C ${80} ${76}, ${84} ${57}, ${81} ${36}`}
          fill="none"
          stroke={strokeColor}
          strokeWidth="3.5"
          opacity="0.8"
          strokeLinecap="round"
        />
      </g>
    </motion.svg>
  );
};
