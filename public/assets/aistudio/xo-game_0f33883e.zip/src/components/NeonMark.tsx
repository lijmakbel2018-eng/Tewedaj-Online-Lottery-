import React from 'react';
import { motion } from 'motion/react';
import type { Player } from '../utils/gameLogic';

interface NeonMarkProps {
  type: Player;
  isWinning?: boolean;
  isGhost?: boolean;
  theme?: 'neon' | 'cyberDark' | 'paper';
  seed?: number;
}

export const NeonMark: React.FC<NeonMarkProps> = ({
  type,
  isWinning = false,
  isGhost = false,
  theme = 'neon',
}) => {
  // If paper theme is selected as alternate
  if (theme === 'paper') {
    return (
      <motion.svg
        initial={isGhost ? false : { scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: isGhost ? 0.35 : 1 }}
        viewBox="0 0 100 100"
        className="w-full h-full p-2"
      >
        {type === 'X' ? (
          <g stroke="#1c1917" strokeWidth="10" strokeLinecap="round">
            <line x1="20" y1="20" x2="80" y2="80" />
            <line x1="80" y1="20" x2="20" y2="80" />
          </g>
        ) : (
          <circle cx="50" cy="50" r="32" fill="none" stroke="#e11d48" strokeWidth="10" strokeLinecap="round" />
        )}
      </motion.svg>
    );
  }

  // Neon & CyberDark Theme (Exact match to the user's uploaded reference image!)
  if (type === 'X') {
    // 3D White Embossed Cross with Vibrant Fiery Red / Magenta Neon Glow
    return (
      <motion.div
        initial={isGhost ? false : { scale: 0.3, opacity: 0 }}
        animate={{
          scale: 1,
          opacity: isGhost ? 0.35 : 1,
        }}
        transition={{ type: 'spring', stiffness: 450, damping: 24 }}
        className={`w-full h-full flex items-center justify-center p-2.5 relative select-none pointer-events-none ${
          isWinning ? 'animate-pulse' : ''
        }`}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full overflow-visible"
          style={{
            filter: isGhost
              ? 'drop-shadow(0 0 6px rgba(255, 23, 68, 0.5))'
              : isWinning
              ? 'drop-shadow(0 0 10px #ff1744) drop-shadow(0 0 25px #ff1744) drop-shadow(0 0 45px #ff0055)'
              : 'drop-shadow(0 0 8px rgba(255, 23, 68, 0.95)) drop-shadow(0 0 18px rgba(255, 0, 85, 0.75)) drop-shadow(0 0 32px rgba(255, 0, 50, 0.45))',
          }}
        >
          <defs>
            {/* Linear gradient for 3D bevel sheen on white surface */}
            <linearGradient id="bevel-x" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="45%" stopColor="#f8fafc" />
              <stop offset="80%" stopColor="#e2e8f0" />
              <stop offset="100%" stopColor="#cbd5e1" />
            </linearGradient>

            {/* Neon Red/Crimson Inner Glow */}
            <radialGradient id="neon-glow-red" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ff5252" stopOpacity="0.9" />
              <stop offset="60%" stopColor="#ff1744" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#d50000" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Deep Ambient Neon Red Backing Aura */}
          <g opacity={isGhost ? 0.3 : 0.85}>
            <line x1="20" y1="20" x2="80" y2="80" stroke="#ff1744" strokeWidth="26" strokeLinecap="square" />
            <line x1="80" y1="20" x2="20" y2="80" stroke="#ff1744" strokeWidth="26" strokeLinecap="square" />
          </g>

          {/* 3D Drop Shadow offset underneath the white cross */}
          <g transform="translate(2, 3)" opacity={isGhost ? 0 : 0.6}>
            <line x1="20" y1="20" x2="80" y2="80" stroke="#88001b" strokeWidth="17" strokeLinecap="square" />
            <line x1="80" y1="20" x2="20" y2="80" stroke="#88001b" strokeWidth="17" strokeLinecap="square" />
          </g>

          {/* Main Crisp 3D White Embossed Cross */}
          <g stroke="url(#bevel-x)" strokeWidth="16" strokeLinecap="square">
            <line x1="20" y1="20" x2="80" y2="80" />
            <line x1="80" y1="20" x2="20" y2="80" />
          </g>

          {/* Top highlight ridge for genuine 3D arcade token feel */}
          <g stroke="#ffffff" strokeWidth="5" strokeLinecap="round" opacity="0.95">
            <line x1="22" y1="20" x2="78" y2="76" />
            <line x1="78" y1="20" x2="22" y2="76" />
          </g>
        </svg>
      </motion.div>
    );
  }

  // 'O' Mark: 3D White Embossed Ring with Vibrant Electric Blue / Cyan Neon Glow
  return (
    <motion.div
      initial={isGhost ? false : { scale: 0.3, opacity: 0 }}
      animate={{
        scale: 1,
        opacity: isGhost ? 0.35 : 1,
      }}
      transition={{ type: 'spring', stiffness: 450, damping: 24 }}
      className={`w-full h-full flex items-center justify-center p-2.5 relative select-none pointer-events-none ${
        isWinning ? 'animate-pulse' : ''
      }`}
    >
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full overflow-visible"
        style={{
          filter: isGhost
            ? 'drop-shadow(0 0 6px rgba(0, 229, 255, 0.5))'
            : isWinning
            ? 'drop-shadow(0 0 10px #00e5ff) drop-shadow(0 0 25px #0070f3) drop-shadow(0 0 45px #00b4d8)'
            : 'drop-shadow(0 0 8px rgba(0, 229, 255, 0.95)) drop-shadow(0 0 18px rgba(0, 112, 243, 0.8)) drop-shadow(0 0 32px rgba(0, 150, 255, 0.45))',
        }}
      >
        <defs>
          <linearGradient id="bevel-o" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="50%" stopColor="#f0f9ff" />
            <stop offset="85%" stopColor="#e0f2fe" />
            <stop offset="100%" stopColor="#bae6fd" />
          </linearGradient>
        </defs>

        {/* Deep Ambient Neon Blue Backing Aura */}
        <circle
          cx="50"
          cy="50"
          r="30"
          fill="none"
          stroke="#00e5ff"
          strokeWidth="24"
          opacity={isGhost ? 0.3 : 0.85}
        />

        {/* 3D Drop Shadow offset underneath the white ring */}
        <circle
          cx="52"
          cy="53"
          r="30"
          fill="none"
          stroke="#002d62"
          strokeWidth="16"
          opacity={isGhost ? 0 : 0.6}
        />

        {/* Main Crisp 3D White Embossed Ring */}
        <circle
          cx="50"
          cy="50"
          r="30"
          fill="none"
          stroke="url(#bevel-o)"
          strokeWidth="15"
        />

        {/* Top Arc Specular Highlight for 3D metallic/glass sheen */}
        <path
          d="M 28 32 A 30 30 0 0 1 72 32"
          fill="none"
          stroke="#ffffff"
          strokeWidth="4"
          strokeLinecap="round"
          opacity="0.95"
        />
      </svg>
    </motion.div>
  );
};
