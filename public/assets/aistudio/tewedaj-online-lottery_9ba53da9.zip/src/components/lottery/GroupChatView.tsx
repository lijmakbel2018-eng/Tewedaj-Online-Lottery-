import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, 
  Send, 
  Sparkles, 
  ShieldCheck, 
  Users, 
  Clock,
  X,
  Reply,
  Trash2,
  Camera,
  Video,
} from 'lucide-react';
import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  limit 
} from 'firebase/firestore';
import { db, safeFirestoreSetDoc } from '../../lib/firebase';
import { Language, UserProfile } from '../../types/lottery';

interface GroupChatViewProps {
  user: UserProfile;
  lang: Language;
  triggerHaptic?: (style: 'light' | 'medium' | 'heavy') => void;
  playNotificationSound?: (type: 'click' | 'win' | 'alert') => void;
}

interface ChatMsg {
  id: string;
  senderName: string;
  senderPhone: string;
  text: string;
  timestamp: string;
  isAdmin?: boolean;
  imageUrl?: string;
  videoUrl?: string;
  replyTo?: {
    id: string;
    senderName: string;
    text: string;
  };
}

export const GroupChatView: React.FC<GroupChatViewProps> = ({
  user,
  lang,
  triggerHaptic,
  playNotificationSound,
}) => {
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [inputText, setInputText] = useState('');
  const [sending, setSending] = useState(false);
  const [replyTo, setReplyTo] = useState<ChatMsg | null>(null);
  const [highlightedId, setHighlightedId] = useState<string | null>(null);
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [attachedVideo, setAttachedVideo] = useState<string | null>(null);
  const [mediaError, setMediaError] = useState<string | null>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const messageRefs = useRef<Record<string, HTMLDivElement | null>>({});

  // 1. Real-time Firebase Firestore synchronization
  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    try {
      const q = query(collection(db, 'group_chat'), orderBy('timestamp', 'asc'), limit(150));
      unsubscribe = onSnapshot(q, (snapshot) => {
        const firestoreMsgs: ChatMsg[] = [];
        snapshot.forEach((d) => {
          const data = d.data() as ChatMsg;
          if (data && data.id) {
            firestoreMsgs.push(data);
          }
        });
        if (firestoreMsgs.length > 0) {
          setMessages(firestoreMsgs);
        }
      }, (err) => {
        console.warn('[Firebase GroupChat onSnapshot Error, using server fallback]', err);
      });
    } catch (e) {
      console.warn('[Firebase GroupChat init failed]', e);
    }

    // Server fallback polling
    const fetchServerMessages = async () => {
      try {
        const res = await fetch('/api/group/chat/messages');
        if (!res.ok) return;
        const data = await res.json();
        if (data.ok && Array.isArray(data.messages) && data.messages.length > 0) {
          setMessages(prev => {
            const idMap = new Map<string, ChatMsg>();
            prev.forEach(m => idMap.set(m.id, m));
            data.messages.forEach((m: ChatMsg) => idMap.set(m.id, m));
            const merged = Array.from(idMap.values());
            merged.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
            return merged;
          });
        }
      } catch {}
    };

    fetchServerMessages();
    const interval = setInterval(fetchServerMessages, 3000);

    return () => {
      if (unsubscribe) unsubscribe();
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const scrollToMessage = (targetId: string) => {
    const el = messageRefs.current[targetId];
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setHighlightedId(targetId);
      triggerHaptic?.('light');
      setTimeout(() => setHighlightedId(null), 1500);
    }
  };

  const cleanUserPhone = user.phone ? user.phone.replace(/\D/g, '') : '';
  const isOwner = cleanUserPhone.includes('910961881') || user.telegramUsername?.toLowerCase() === 'lij_makbel';

  const handleMediaFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video') => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 15 * 1024 * 1024) {
      setMediaError(lang === 'am' ? 'ፋይሉ ከ 15MB መብለጥ የለበትም' : 'File must be under 15MB');
      return;
    }
    setMediaError(null);
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      if (type === 'image') {
        setAttachedImage(result);
        setAttachedVideo(null);
      } else {
        setAttachedVideo(result);
        setAttachedImage(null);
      }
      triggerHaptic?.('light');
    };
    reader.readAsDataURL(file);
  };

  const handleDeleteMessage = async (msgId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm(lang === 'am' ? 'ይህንን መልዕክት መሰረዝ ይፈልጋሉ?' : 'Delete this message?')) {
      return;
    }
    triggerHaptic?.('medium');
    playNotificationSound?.('click');

    // Delete locally and from Firebase Firestore directly
    setMessages(prev => prev.filter(m => m.id !== msgId));
    try {
      await deleteDoc(doc(db, 'group_chat', msgId));
    } catch (err) {
      console.warn('[Firebase deleteDoc error]', err);
    }

    // Also call server API
    try {
      await fetch('/api/group/chat/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messageId: msgId,
          adminPhone: user.phone,
          adminUsername: user.telegramUsername,
        }),
      });
    } catch (err) {
      console.error('Delete chat message server error', err);
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    const txt = inputText.trim();
    if (!txt && !attachedImage && !attachedVideo) return;
    if (sending) return;

    setSending(true);
    triggerHaptic?.('medium');
    playNotificationSound?.('click');

    const cleanPhone = user.phone ? user.phone.replace(/\D/g, '') : '';
    const isAdmin = cleanPhone.includes('910961881') || user.telegramUsername?.toLowerCase() === 'lij_makbel';

    const replyPayload = replyTo ? {
      id: replyTo.id,
      senderName: replyTo.senderPhone?.includes('0910961881') ? '👑 Owner' : (replyTo.senderPhone ? `(${replyTo.senderPhone.slice(-4)})` : replyTo.senderName),
      text: replyTo.text,
    } : undefined;

    const newId = 'gc_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const newChatMsg: ChatMsg = {
      id: newId,
      senderName: user.phone ? `(${user.phone.slice(-4)})` : (user.fullName || 'ደንበኛ'),
      senderPhone: user.phone || '0910961881',
      text: txt,
      timestamp: new Date().toISOString(),
      isAdmin,
      imageUrl: attachedImage || undefined,
      videoUrl: attachedVideo || undefined,
      replyTo: replyPayload,
    };

    // Optimistic local update
    setMessages(prev => [...prev, newChatMsg]);
    setInputText('');
    setAttachedImage(null);
    setAttachedVideo(null);
    setReplyTo(null);

    // 1. Direct write to Firebase Firestore (with quota protection)
    try {
      await safeFirestoreSetDoc(doc(db, 'group_chat', newId), newChatMsg);
    } catch (firebaseErr) {
      console.warn('[Firebase group_chat setDoc error]', firebaseErr);
    }

    // 2. Also notify backend and Telegram admins
    try {
      await fetch('/api/group/chat/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderName: newChatMsg.senderName,
          senderPhone: newChatMsg.senderPhone,
          text: newChatMsg.text,
          isAdmin,
          imageUrl: newChatMsg.imageUrl,
          videoUrl: newChatMsg.videoUrl,
          replyTo: replyPayload,
        }),
      });
    } catch (err) {
      console.warn('[Server Chat Send fallback/notify]', err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-120px)] bg-slate-950 text-slate-100 overflow-hidden rounded-2xl border border-slate-800/80 shadow-xl">
      {/* Group Header */}
      <div className="bg-slate-900 border-b border-slate-800 p-3.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-500 to-emerald-500 flex items-center justify-center text-slate-950 font-black shadow-lg">
            <Users className="w-5 h-5 text-slate-950 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-black text-yellow-400 text-base sm:text-lg tracking-wide drop-shadow-[0_1px_6px_rgba(250,204,21,0.35)]">
                Tewedaj Online Lottery
              </h3>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <p className="text-[11px] text-slate-400">
              {lang === 'am' ? 'የማህበረሰብ ውይይት (የቀጥታ ስርጭት)' : 'Community Chat (Live)'}
            </p>
          </div>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-slate-950 to-slate-900/40">
        {messages.length === 0 && (
          <div className="py-12 text-center text-slate-500 space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-sky-400">
              <MessageSquare className="w-6 h-6" />
            </div>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              {lang === 'am' 
                ? 'እንኳን ወደ ተወዳጅ ኦንላይን ሎተሪ ማህበረሰብ ቻት በደህና መጡ! ማንኛውንም ጥያቄ ወይም አስተያየት እዚህ መጻፍ ይችላሉ።'
                : 'Welcome to Tewedaj Online Lottery community chat! Feel free to ask questions and discuss.'}
            </p>
          </div>
        )}

        {messages.map((msg) => {
          const isMe = msg.senderPhone === user.phone || msg.senderName === user.fullName;
          const isHighlighted = highlightedId === msg.id;

          return (
            <div
              key={msg.id}
              ref={(el) => {
                messageRefs.current[msg.id] = el;
              }}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} w-full space-y-1 transition duration-300 ${
                isHighlighted ? 'scale-[1.02] filter drop-shadow-[0_0_12px_rgba(56,189,248,0.5)]' : ''
              }`}
            >
              <div className="flex items-center gap-1.5 px-1 text-[10px] text-slate-400">
                <span className={`font-bold ${msg.isAdmin ? 'text-amber-400 font-black' : 'text-slate-300'}`}>
                  {msg.senderPhone.includes('0910961881') ? '👑 Owner' : (msg.senderPhone ? `(${msg.senderPhone.slice(-4)})` : msg.senderName)}
                </span>
                <span>•</span>
                <span>{new Date(msg.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</span>
                {isOwner && (
                  <button
                    type="button"
                    onClick={(e) => handleDeleteMessage(msg.id, e)}
                    className="ml-1 p-0.5 text-rose-400 hover:text-rose-300 hover:bg-rose-950/60 rounded transition active:scale-90"
                    title={lang === 'am' ? 'መልዕክት አጥፋ' : 'Delete message'}
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Message Bubble */}
              <div 
                className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs sm:text-sm leading-relaxed shadow-md text-left transition relative group cursor-pointer ${
                  msg.isAdmin 
                    ? 'bg-gradient-to-r from-amber-500/20 via-yellow-500/20 to-amber-500/10 border border-amber-500/40 text-amber-100 font-medium'
                    : isMe 
                      ? 'bg-emerald-500 text-slate-950 font-medium rounded-tr-sm shadow-emerald-500/10' 
                      : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-sm'
                }`}
                onClick={() => {
                  setReplyTo(msg);
                  triggerHaptic?.('light');
                }}
              >
                {/* Telegram-style Quoted Reply Box */}
                {msg.replyTo && (
                  <div
                    onClick={(e) => {
                      e.stopPropagation();
                      if (msg.replyTo?.id) {
                        scrollToMessage(msg.replyTo.id);
                      }
                    }}
                    className={`mb-2 pl-2.5 pr-2 py-1 rounded-xl text-left border-l-4 cursor-pointer transition select-none ${
                      isMe 
                        ? 'bg-slate-950/20 border-slate-950 text-slate-900 hover:bg-slate-950/30'
                        : msg.isAdmin 
                          ? 'bg-amber-950/40 border-amber-400 text-amber-200 hover:bg-amber-950/60'
                          : 'bg-slate-800/80 border-sky-400 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className={`text-[10px] font-black leading-tight flex items-center gap-1 ${
                      isMe ? 'text-slate-950 font-black' : msg.isAdmin ? 'text-amber-300' : 'text-sky-400'
                    }`}>
                      <Reply className="w-2.5 h-2.5 inline" />
                      <span>{msg.replyTo.senderName}</span>
                    </div>
                    <div className="text-[11px] truncate opacity-90 max-w-[240px]">
                      {msg.replyTo.text}
                    </div>
                  </div>
                )}

                {/* Attached Image */}
                {msg.imageUrl && (
                  <div className="mb-2 rounded-xl overflow-hidden border border-slate-700/80 bg-slate-950 max-h-56">
                    <img src={msg.imageUrl} alt="Shared media" className="max-h-56 w-auto object-contain mx-auto" />
                  </div>
                )}

                {/* Attached Video */}
                {msg.videoUrl && (
                  <div className="mb-2 rounded-xl overflow-hidden border border-slate-700/80 bg-slate-950 max-h-56">
                    <video src={msg.videoUrl} controls className="max-h-56 w-auto object-contain mx-auto" />
                  </div>
                )}

                {/* Main Message Text */}
                {msg.text && (
                  <div className="break-words">
                    {msg.text}
                  </div>
                )}
              </div>
            </div>
          );
        })}
        <div ref={chatEndRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={handleSend} className="bg-slate-900 border-t border-slate-800 p-3 shrink-0 flex flex-col gap-2">
        {/* Telegram-style Reply Preview Bar */}
        {replyTo && (
          <div className="bg-slate-800/90 border border-slate-700/80 rounded-xl px-3 py-1.5 flex items-center justify-between gap-2 text-xs animate-in slide-in-from-bottom-2">
            <div className="flex items-center gap-2 min-w-0 border-l-2 border-sky-400 pl-2">
              <Reply className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <div className="min-w-0 text-left">
                <div className="text-[10px] font-bold text-sky-400 truncate">
                  Replying to {replyTo.senderPhone?.includes('0910961881') ? '👑 Owner' : (replyTo.senderPhone ? `(${replyTo.senderPhone.slice(-4)})` : replyTo.senderName)}
                </div>
                <div className="text-[11px] text-slate-300 truncate max-w-[220px]">
                  {replyTo.text}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setReplyTo(null)}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700/60 transition"
              title="ምላሽ ሰርዝ"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Attached Media Preview */}
        {(attachedImage || attachedVideo) && (
          <div className="bg-slate-950 border border-emerald-500/40 rounded-xl p-2 flex items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              {attachedImage ? (
                <img src={attachedImage} alt="Preview" className="w-10 h-10 object-cover rounded-lg" />
              ) : (
                <Video className="w-6 h-6 text-emerald-400" />
              )}
              <span className="text-emerald-300 font-bold truncate">
                {attachedImage ? (lang === 'am' ? 'ምስል ተያይዟል' : 'Image attached') : (lang === 'am' ? 'ቪዲዮ ተያይዟል' : 'Video attached')}
              </span>
            </div>
            <button
              type="button"
              onClick={() => { setAttachedImage(null); setAttachedVideo(null); }}
              className="p-1 text-slate-400 hover:text-rose-400"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {mediaError && (
          <div className="text-[11px] text-rose-400 font-medium px-1">{mediaError}</div>
        )}

        <div className="flex items-center gap-2">
          {/* Admin-only Image & Video Upload Buttons */}
          {isOwner && (
            <div className="flex items-center gap-1">
              <label className="p-2.5 bg-slate-950 hover:bg-slate-800 text-emerald-400 border border-slate-800 rounded-xl cursor-pointer transition active:scale-95" title={lang === 'am' ? 'ምስል አያይዝ' : 'Attach image'}>
                <Camera className="w-4 h-4" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleMediaFileChange(e, 'image')}
                  className="hidden"
                />
              </label>
              <label className="p-2.5 bg-slate-950 hover:bg-slate-800 text-sky-400 border border-slate-800 rounded-xl cursor-pointer transition active:scale-95" title={lang === 'am' ? 'ቪዲዮ አያይዝ' : 'Attach video'}>
                <Video className="w-4 h-4" />
                <input
                  type="file"
                  accept="video/*"
                  onChange={(e) => handleMediaFileChange(e, 'video')}
                  className="hidden"
                />
              </label>
            </div>
          )}

          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={lang === 'am' ? 'መልዕክት ይጻፉ...' : 'Type a message...'}
            className="flex-1 bg-slate-950 border border-slate-800 focus:border-sky-500 rounded-xl px-3.5 py-2.5 text-white text-xs sm:text-sm focus:outline-none focus:ring-1 focus:ring-sky-500"
          />
          <button
            type="submit"
            disabled={(!inputText.trim() && !attachedImage && !attachedVideo) || sending}
            className="bg-sky-500 hover:bg-sky-400 active:scale-95 disabled:opacity-50 text-slate-950 font-black px-4 py-2.5 rounded-xl transition flex items-center justify-center shadow-lg shadow-sky-500/20 cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};
