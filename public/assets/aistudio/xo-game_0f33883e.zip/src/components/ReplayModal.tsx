import React, { useState, useEffect } from 'react';
import { Play, Pause, ChevronLeft, ChevronRight, RotateCcw, X } from 'lucide-react';
import type { MoveRecord, GridDimension } from '../utils/gameLogic';
import type { Translations } from '../utils/translations';
import { DoodleGrid } from './DoodleGrid';
import { sound } from '../utils/audio';

interface ReplayModalProps {
  moves: MoveRecord[];
  size: GridDimension;
  isOpen: boolean;
  onClose: () => void;
  t: Translations;
  theme: 'neon' | 'cyberDark' | 'paper';
}

export const ReplayModal: React.FC<ReplayModalProps> = ({
  moves,
  size,
  isOpen,
  onClose,
  t,
  theme,
}) => {
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setCurrentStep(moves.length);
      setIsPlaying(false);
    }
  }, [isOpen, moves.length]);

  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (isPlaying) {
      timer = setInterval(() => {
        setCurrentStep((prev) => {
          if (prev >= moves.length) {
            setIsPlaying(false);
            return prev;
          }
          const next = prev + 1;
          const currentMove = moves[prev];
          if (currentMove) {
            sound.playNeonLaser(currentMove.player);
          }
          return next;
        });
      }, 650);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isPlaying, moves]);

  if (!isOpen) return null;

  // Build the board at current step
  const currentBoard = Array(size * size).fill(null);
  for (let i = 0; i < currentStep; i++) {
    const m = moves[i];
    if (m) {
      currentBoard[m.cellIndex] = m.player;
    }
  }

  const isNeon = theme === 'neon' || theme === 'cyberDark';
  const modalBg = isNeon
    ? 'bg-[#130f2b] text-white border border-indigo-800/80'
    : 'bg-white text-stone-900 border border-stone-200';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className={`relative w-full max-w-lg rounded-2xl p-6 shadow-2xl ${modalBg}`}>
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-indigo-900/50">
          <div>
            <h3 className="text-lg font-bold">{t.replay}</h3>
            <p className="text-xs opacity-75">
              {t.step} {currentStep} / {moves.length}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Board View */}
        <div className="py-4">
          <DoodleGrid
            board={currentBoard}
            size={size}
            turn="X"
            winnerInfo={null}
            onCellClick={() => {}}
            disabled={true}
            theme={theme}
          />
        </div>

        {/* Controls */}
        <div className="flex flex-col gap-3 pt-2 border-t border-indigo-900/50">
          <input
            type="range"
            min={0}
            max={moves.length}
            value={currentStep}
            onChange={(e) => {
              setIsPlaying(false);
              setCurrentStep(Number(e.target.value));
            }}
            className="w-full accent-cyan-400 cursor-pointer"
          />

          <div className="flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => {
                setIsPlaying(false);
                setCurrentStep(0);
              }}
              className="p-2 rounded-lg border border-indigo-700/60 hover:bg-white/10 transition-colors cursor-pointer"
              title="Reset to start"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              type="button"
              disabled={currentStep <= 0}
              onClick={() => {
                setIsPlaying(false);
                setCurrentStep((p) => Math.max(0, p - 1));
              }}
              className="p-2 rounded-lg border border-indigo-700/60 disabled:opacity-40 hover:bg-white/10 transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => {
                if (currentStep >= moves.length) {
                  setCurrentStep(0);
                }
                setIsPlaying((p) => !p);
              }}
              className="px-4 py-2 flex items-center gap-2 rounded-lg bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400 transition-colors cursor-pointer"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span className="text-xs">{isPlaying ? 'Pause' : 'Play'}</span>
            </button>

            <button
              type="button"
              disabled={currentStep >= moves.length}
              onClick={() => {
                setIsPlaying(false);
                setCurrentStep((p) => Math.min(moves.length, p + 1));
              }}
              className="p-2 rounded-lg border border-indigo-700/60 disabled:opacity-40 hover:bg-white/10 transition-colors cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
