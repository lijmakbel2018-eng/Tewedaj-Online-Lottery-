import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc, 
  setDoc, 
  getDocs, 
  deleteDoc 
} from 'firebase/firestore';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Firebase Firestore Configuration
const firebaseConfig = {
  apiKey: "AIzaSyCTdi7gEKxuitfXoOyi2PNZ5KntKNqGhPE",
  authDomain: "tewedaj-online-lottery.firebaseapp.com",
  projectId: "tewedaj-online-lottery",
  storageBucket: "tewedaj-online-lottery.firebasestorage.app",
  messagingSenderId: "120710535914",
  appId: "1:120710535914:web:cc29dc90850bd9e7d25593",
  measurementId: "G-2WL0DVD0CE"
};

const fbApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const firestore = getFirestore(fbApp);

// Telegram Bot Configuration
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '8577097699:AAEwbW_yXyU1q0RgRi7J0GXAEnKboY6wFzM';
const BOT_USERNAME = 'Tewedaj_Online_Lottery_bot';
const APP_URL = process.env.APP_URL || 'https://ais-dev-5nv5ynlx4w7f7zevtpent5-650741114731.europe-west1.run.app';

// Official Admin & Support Contact Details
const OFFICIAL_ADMIN = {
  phone: '0910961881',
  supportUsername: 'lij_makbel',
  fullName: 'Makbel Maregu',
  telebirr: '0910961881',
  cbeAccount: '1000321337124',
};

app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Official Tewedaj Online Lottery Merchant Details
const OFFICIAL_MERCHANT = {
  fullName: OFFICIAL_ADMIN.fullName,
  telebirr: OFFICIAL_ADMIN.telebirr,
  cbeAccount: OFFICIAL_ADMIN.cbeAccount,
  platform: 'Tewedaj Online Lottery (ተወዳጅ ኦንላይን ሎተሪ)',
  telegramBot: '@' + BOT_USERNAME,
  supportHandle: '@' + OFFICIAL_ADMIN.supportUsername,
  adminPhone: OFFICIAL_ADMIN.phone,
  status: 'active',
  lotteries: [
    { title: 'ባለ 1,000 ብር ደራሽ', price: 10, jackpot: 1000 },
    { title: 'ባለ 5,000 ብር ደራሽ', price: 50, jackpot: 5000 },
    { title: 'ባለ 10,000 ብር ደራሽ', price: 100, jackpot: 10000 },
    { title: 'ባለ 20,000 ብር ደራሽ', price: 200, jackpot: 20000 },
  ],
};

// ----------------------------------------------------
// Persistent Admin Chats Storage
// ----------------------------------------------------
const ADMIN_CHATS_FILE = path.join(__dirname, 'admin_chats.json');
let adminChatIds: number[] = [];

try {
  if (fs.existsSync(ADMIN_CHATS_FILE)) {
    const raw = fs.readFileSync(ADMIN_CHATS_FILE, 'utf-8');
    adminChatIds = JSON.parse(raw);
  }
} catch {
  adminChatIds = [];
}

function saveAdminChatIds() {
  try {
    fs.writeFileSync(ADMIN_CHATS_FILE, JSON.stringify(Array.from(new Set(adminChatIds)), null, 2));
  } catch (err) {
    console.error('[Save Admin Chats Error]', err);
  }
}

function addAdminChatId(chatId: number) {
  if (!adminChatIds.includes(chatId)) {
    adminChatIds.push(chatId);
    saveAdminChatIds();
    console.log(`[Admin Registered] Chat ID: ${chatId}. Total Admins: ${adminChatIds.length}`);
  }
}

// ----------------------------------------------------
// Persistent User Wallets Store (for Bot and Mini App)
// ----------------------------------------------------
export interface UserWallet {
  userId: string;
  telegramId?: string;
  customerId?: string;
  phone: string;
  fullName: string;
  password?: string;
  username?: string;
  profileImage?: string;
  walletBalance: number;
  ticketsCount: number;
  totalWon: number;
  language: 'am' | 'en';
  registeredAt?: string;
  lastActive?: string;
  isAdmin?: boolean;
  notifications?: { id: string; message: string; timestamp: string; isRead: boolean }[];
}

function safeWriteJsonSync(filePath: string, data: any) {
  try {
    const jsonStr = JSON.stringify(data, null, 2);
    const tmpFile = `${filePath}.tmp.${Date.now()}`;
    fs.writeFileSync(tmpFile, jsonStr, 'utf-8');
    if (fs.existsSync(filePath)) {
      try {
        fs.copyFileSync(filePath, `${filePath}.bak`);
      } catch {}
    }
    fs.renameSync(tmpFile, filePath);
  } catch (err) {
    console.error(`[Atomic Save Error: ${filePath}]`, err);
  }
}

function safeReadJsonSync<T>(filePath: string, fallback: T): T {
  try {
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf-8').trim();
      if (content) {
        return JSON.parse(content) as T;
      }
    }
  } catch (err) {
    console.warn(`[Read Primary JSON Failed: ${filePath}, trying backup]`, err);
  }
  try {
    const bakFile = `${filePath}.bak`;
    if (fs.existsSync(bakFile)) {
      const content = fs.readFileSync(bakFile, 'utf-8').trim();
      if (content) {
        return JSON.parse(content) as T;
      }
    }
  } catch (bakErr) {
    console.error(`[Read Backup JSON Failed: ${filePath}]`, bakErr);
  }
  return fallback;
}

export async function syncWalletToFirestore(wallet: UserWallet) {
  try {
    const key = wallet.phone || wallet.userId || wallet.telegramId;
    if (!key) return;
    const cleanKey = String(key).replace(/[\/\s]/g, '_');
    await setDoc(doc(firestore, 'wallets', cleanKey), wallet, { merge: true });
  } catch (err) {
    console.warn('[Firestore Sync Wallet Error]', err);
  }
}

const WALLETS_FILE = path.join(__dirname, 'wallets_store.json');
let userWallets: Record<string, UserWallet> = safeReadJsonSync<Record<string, UserWallet>>(WALLETS_FILE, {});

function saveUserWallets(force = false) {
  if (!force && Object.keys(userWallets).length === 0 && fs.existsSync(WALLETS_FILE)) {
    const existing = safeReadJsonSync<Record<string, UserWallet>>(WALLETS_FILE, {});
    if (Object.keys(existing).length > 0) return;
  }
  safeWriteJsonSync(WALLETS_FILE, userWallets);
  for (const w of Object.values(userWallets)) {
    syncWalletToFirestore(w).catch(() => {});
  }
}

// ----------------------------------------------------
// Strict Ethiopian Phone Normalization & Deduplication
// ----------------------------------------------------
export function normalizeEthiopianPhone(raw?: string): string {
  if (!raw) return '';
  let clean = String(raw).replace(/\D/g, '');
  if (clean.startsWith('251')) {
    clean = '0' + clean.slice(3);
  } else if (!clean.startsWith('0') && (clean.startsWith('9') || clean.startsWith('7'))) {
    clean = '0' + clean;
  }
  return clean;
}

export function findWalletByPhone(phone?: string): UserWallet | undefined {
  if (!phone) return undefined;
  const clean = normalizeEthiopianPhone(phone);
  if (!clean || clean.length < 9) return undefined;
  const suffix = clean.slice(-9);

  for (const w of Object.values(userWallets)) {
    if (w.phone) {
      const wClean = normalizeEthiopianPhone(w.phone);
      if (wClean.length >= 9 && wClean.slice(-9) === suffix) {
        return w;
      }
    }
  }
  return undefined;
}

export function deduplicateWallets(): { removedCount: number; remainingCount: number } {
  // Never delete any registered user records!
  return {
    removedCount: 0,
    remainingCount: Object.keys(userWallets).length,
  };
}

// Initial deduplication on startup
deduplicateWallets();

// ----------------------------------------------------
// Persistent Tickets Store
// ----------------------------------------------------
export interface SyncedTicket {
  id: string;
  lotteryId: string;
  lotteryTitleAm: string;
  lotteryTitleEn: string;
  ticketNumber: string;
  userId: string;
  userName: string;
  userPhone: string;
  userTelegram?: string;
  userAvatar?: string;
  pricePaid: number;
  purchasedAt: string;
  paymentMethod: string;
  paymentReference: string;
  round?: number;
  status: 'active' | 'won' | 'lost' | 'refunded';
  prizeWon?: number;
  prizeTitleAm?: string;
  prizeTitleEn?: string;
  securityHash: string;
}

export async function syncTicketToFirestore(ticket: SyncedTicket) {
  try {
    if (!ticket.id) return;
    await setDoc(doc(firestore, 'tickets', String(ticket.id)), ticket, { merge: true });
  } catch (err) {
    console.warn('[Firestore Sync Ticket Error]', err);
  }
}

const TICKETS_FILE = path.join(__dirname, 'tickets_store.json');
let syncedTickets: SyncedTicket[] = safeReadJsonSync<SyncedTicket[]>(TICKETS_FILE, []);

function saveTickets() {
  if (syncedTickets.length === 0 && fs.existsSync(TICKETS_FILE)) {
    const existing = safeReadJsonSync<SyncedTicket[]>(TICKETS_FILE, []);
    if (existing.length > 0) return;
  }
  safeWriteJsonSync(TICKETS_FILE, syncedTickets.slice(0, 5000));
  for (const t of syncedTickets.slice(0, 100)) {
    syncTicketToFirestore(t).catch(() => {});
  }
}

export function computeActiveLotteryCounts(): Record<string, number> {
  const lotteryCounts: Record<string, number> = {
    lot_derash_1000: 0,
    lot_derash_5000: 0,
    lot_derash_10000: 0,
    lot_derash_20000: 0,
  };
  for (const t of syncedTickets) {
    if (t.status === 'active') {
      const key = t.lotteryId || (t.pricePaid === 10 ? 'lot_derash_1000' : t.pricePaid === 50 ? 'lot_derash_5000' : t.pricePaid === 100 ? 'lot_derash_10000' : 'lot_derash_20000');
      if (lotteryCounts[key] !== undefined) {
        lotteryCounts[key]++;
      } else {
        lotteryCounts[key] = 1;
      }
    }
  }
  return lotteryCounts;
}

export function findOrCreateWallet(params: { userId?: string; phone?: string; telegramId?: string; fullName?: string; username?: string; profileImage?: string }): UserWallet {
  const { userId, phone, telegramId, fullName, username, profileImage } = params;
  const cleanPhone = normalizeEthiopianPhone(phone);
  const searchTgId = telegramId ? String(telegramId) : (userId && !cleanPhone ? String(userId) : '');

  // 1. Direct match by phone first (phone is unique primary identity)
  if (cleanPhone && cleanPhone.length >= 9) {
    const existing = findWalletByPhone(cleanPhone);
    if (existing) {
      if (fullName && (!existing.fullName || existing.fullName === existing.phone || existing.fullName === 'ተጠቃሚ')) existing.fullName = fullName;
      if (username && !existing.username) existing.username = username;
      if (profileImage && !existing.profileImage) existing.profileImage = profileImage;
      if (!existing.phone) existing.phone = cleanPhone;
      if (searchTgId && !existing.telegramId) existing.telegramId = searchTgId;
      if (!existing.customerId) {
        existing.customerId = 'TEWEDAJ-' + (existing.telegramId || existing.phone || existing.userId).slice(-6);
      }
      saveUserWallets();
      return existing;
    }
  }

  // 2. Direct match by userId or telegramId
  if (searchTgId) {
    for (const [k, w] of Object.entries(userWallets)) {
      if (k === searchTgId || k === `tg_${searchTgId}` || w.userId === searchTgId || (w.telegramId && w.telegramId === searchTgId)) {
        if (cleanPhone && cleanPhone.length >= 9) {
          w.phone = cleanPhone;
          // If cleanPhone is 10 digits and not already occupied, index under phone too without deleting original key
          if (cleanPhone.length === 10 && k !== cleanPhone && !userWallets[cleanPhone]) {
            userWallets[cleanPhone] = w;
          }
        }
        if (username && !w.username) w.username = username;
        if (profileImage && !w.profileImage) w.profileImage = profileImage;
        if (searchTgId && !w.telegramId) w.telegramId = searchTgId;
        if (fullName && (!w.fullName || w.fullName === 'ተጠቃሚ')) w.fullName = fullName;
        if (!w.customerId) {
          w.customerId = 'TEWEDAJ-' + (w.telegramId || w.phone || w.userId).slice(-6);
        }
        saveUserWallets();
        return w;
      }
    }
  }

  // 3. Create new wallet if not found
  const canonicalKey = cleanPhone && cleanPhone.length === 10 
    ? cleanPhone 
    : (searchTgId ? `tg_${searchTgId}` : (userId || `usr_${Date.now()}`));

  const generatedCid = 'TEWEDAJ-' + (searchTgId || cleanPhone || canonicalKey).slice(-6);

  const isNew = !userWallets[canonicalKey];
  userWallets[canonicalKey] = {
    userId: canonicalKey,
    telegramId: searchTgId || '',
    customerId: generatedCid,
    phone: cleanPhone || '',
    fullName: (fullName && fullName.trim()) ? fullName.trim() : (cleanPhone || (username ? username : `ተጠቃሚ (${searchTgId || canonicalKey})`)),
    username: username || '',
    profileImage: profileImage || '',
    walletBalance: 0,
    ticketsCount: 0,
    totalWon: 0,
    language: 'am',
    registeredAt: new Date().toISOString(),
  };
  saveUserWallets();

  if (isNew) {
    const readableRegDate = new Date().toLocaleString('en-US', { timeZone: 'Africa/Addis_Ababa' });
    const tgRegMessage = 
      `👤 <b>አዲስ ተጠቃሚ ተመዝግቧል! (New User Registered)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>ሙሉ ስም:</b> <b>${userWallets[canonicalKey].fullName}</b>\n` +
      `🆔 <b>መለያ (CID):</b> <code>${generatedCid}</code>\n` +
      (cleanPhone ? `📱 <b>ስልክ:</b> <code>${cleanPhone}</code>\n` : '') +
      (username ? `💬 <b>ቴሌግራም:</b> @${username.replace('@', '')}\n` : '') +
      `⏰ <b>ሰዓት:</b> ${readableRegDate}\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `<i>ተወዳጅ ኦንላይን ሎተሪ (Tewedaj Online Lottery)</i>`;

    notifyAllAdmins(tgRegMessage, {
      inline_keyboard: [
        [
          { text: '👑 የአድሚን ዳሽቦርድ (Admin)', url: APP_URL },
        ],
      ],
    }).catch(() => {});
  }

  return userWallets[canonicalKey];
}

function getOrCreateWallet(chatId: number, from?: any, phone?: string): UserWallet {
  const cleanPhone = phone || '';
  const fullName = from?.first_name ? `${from.first_name} ${from.last_name || ''}`.trim() : (cleanPhone || '');
  const username = from?.username ? `@${from.username}` : '';
  const wallet = findOrCreateWallet({
    telegramId: String(chatId),
    userId: String(chatId),
    phone: cleanPhone,
    fullName,
    username,
  });
  if (from?.username && !wallet.username) wallet.username = `@${from.username}`;
  if (fullName && (!wallet.fullName || wallet.fullName === 'ተጠቃሚ')) wallet.fullName = fullName;
  if (!wallet.telegramId) wallet.telegramId = String(chatId);
  saveUserWallets();
  return wallet;
}

// ----------------------------------------------------
// Persistent Transaction Store & Sync
// ----------------------------------------------------
export interface SyncedTransaction {
  id: string;
  ticketId?: string;
  lotteryId?: string;
  lotteryTitleAm?: string;
  userId?: string;
  userName: string;
  userPhone: string;
  amount: number;
  type: 'deposit' | 'withdrawal' | 'ticket_purchase' | 'prize_payout';
  paymentMethod: string;
  referenceNumber: string;
  screenshotUrl?: string;
  timestamp: string;
  status: 'pending' | 'completed' | 'failed';
  approvedBy?: string;
  approvedAt?: string;
  source?: 'bot' | 'mini_app';
}

export async function syncTransactionToFirestore(tx: SyncedTransaction) {
  try {
    if (!tx.id) return;
    await setDoc(doc(firestore, 'transactions', String(tx.id)), tx, { merge: true });
  } catch (err) {
    console.warn('[Firestore Sync Transaction Error]', err);
  }
}

const TX_FILE = path.join(__dirname, 'transactions_store.json');
let syncedTransactions: SyncedTransaction[] = safeReadJsonSync<SyncedTransaction[]>(TX_FILE, []);
syncedTransactions.forEach(t => {
  if (t.type === 'ticket_purchase' && t.status !== 'completed') {
    t.status = 'completed';
  }
});

function saveTransactions() {
  if (syncedTransactions.length === 0 && fs.existsSync(TX_FILE)) {
    const existing = safeReadJsonSync<SyncedTransaction[]>(TX_FILE, []);
    if (existing.length > 0) return;
  }
  safeWriteJsonSync(TX_FILE, syncedTransactions.slice(0, 2000));
  for (const tx of syncedTransactions.slice(0, 100)) {
    syncTransactionToFirestore(tx).catch(() => {});
  }
}

export async function loadAllFromFirestore() {
  try {
    console.log('[Firestore] Synchronizing persistent state from Firebase Firestore...');
    // 1. Wallets
    const walletsSnap = await getDocs(collection(firestore, 'wallets'));
    let loadedWallets = 0;
    walletsSnap.forEach((docSnap) => {
      const data = docSnap.data() as UserWallet;
      if (data && (data.phone || data.userId)) {
        const canonicalKey = data.phone || data.userId;
        userWallets[canonicalKey] = {
          ...userWallets[canonicalKey],
          ...data,
        };
        loadedWallets++;
      }
    });
    console.log(`[Firestore] Successfully loaded ${loadedWallets} wallets.`);

    // 2. Tickets
    const ticketsSnap = await getDocs(collection(firestore, 'tickets'));
    const loadedTicketIds = new Set(syncedTickets.map(t => t.id));
    let newTickets = 0;
    ticketsSnap.forEach((docSnap) => {
      const t = docSnap.data() as SyncedTicket;
      if (t && t.id && !loadedTicketIds.has(t.id)) {
        syncedTickets.unshift(t);
        loadedTicketIds.add(t.id);
        newTickets++;
      }
    });
    console.log(`[Firestore] Successfully loaded ${ticketsSnap.size} tickets (${newTickets} new).`);

    // 3. Transactions
    const txSnap = await getDocs(collection(firestore, 'transactions'));
    const loadedTxIds = new Set(syncedTransactions.map(t => t.id));
    let newTxs = 0;
    txSnap.forEach((docSnap) => {
      const tx = docSnap.data() as SyncedTransaction;
      if (tx && tx.id && !loadedTxIds.has(tx.id)) {
        syncedTransactions.unshift(tx);
        loadedTxIds.add(tx.id);
        newTxs++;
      }
    });
    console.log(`[Firestore] Successfully loaded ${txSnap.size} transactions (${newTxs} new).`);

    // Backfill any active local wallets to Firestore
    for (const w of Object.values(userWallets)) {
      syncWalletToFirestore(w).catch(() => {});
    }
    // Update local file backups
    safeWriteJsonSync(WALLETS_FILE, userWallets);
    safeWriteJsonSync(TICKETS_FILE, syncedTickets.slice(0, 5000));
    safeWriteJsonSync(TX_FILE, syncedTransactions.slice(0, 2000));
  } catch (err) {
    console.error('[Firestore Initial Load Error]', err);
  }
}

// ----------------------------------------------------
// Persistent Support Messages Store
// ----------------------------------------------------
export interface SupportMessage {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  sender: 'user' | 'admin';
  text: string;
  timestamp: string;
  telegramMsgId?: number;
}

const SUPPORT_FILE = path.join(__dirname, 'support_messages.json');
let supportMessages: SupportMessage[] = safeReadJsonSync<SupportMessage[]>(SUPPORT_FILE, []);

function saveSupportMessages() {
  safeWriteJsonSync(SUPPORT_FILE, supportMessages.slice(0, 500));
}

const GROUP_CHAT_FILE = path.join(__dirname, 'group_chat_store.json');
export interface GroupChatMessage {
  id: string;
  senderName: string;
  senderPhone: string;
  text: string;
  timestamp: string;
  isAdmin?: boolean;
  replyTo?: {
    id: string;
    senderName: string;
    text: string;
  };
}
let groupChatMessages: GroupChatMessage[] = safeReadJsonSync<GroupChatMessage[]>(GROUP_CHAT_FILE, []);
function saveGroupChatMessages() {
  safeWriteJsonSync(GROUP_CHAT_FILE, groupChatMessages.slice(0, 500));
}

function escapeHtml(str: string): string {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

async function sendTelegramResponse(chatId: number, text: string, replyMarkup?: any) {
  try {
    const body: any = {
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
      reply_markup: replyMarkup !== undefined ? replyMarkup : { remove_keyboard: true },
    };
    const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const result = (await res.json()) as any;
    if (!result?.ok) {
      const desc = result?.description || '';
      if (desc.includes('chat not found') || desc.includes('blocked') || desc.includes('deactivated') || desc.includes('chat_id is empty')) {
        console.info(`[Telegram Notification Skipped: chat ${chatId} unavailable]`);
        if (adminChatIds.includes(chatId)) {
          adminChatIds = adminChatIds.filter(id => id !== chatId);
          saveAdminChatIds();
        }
        return result;
      }
      console.warn(`[Send Telegram Message HTML failed for chat ${chatId}]:`, desc);
      const plainText = text.replace(/<[^>]*>?/gm, '');
      const fallbackBody = {
        chat_id: chatId,
        text: plainText,
        reply_markup: body.reply_markup,
      };
      const fallbackRes = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fallbackBody),
      });
      return await fallbackRes.json();
    }
    return result;
  } catch (err) {
    console.error('[Send Telegram Message Error]', err);
    return null;
  }
}

async function editTelegramMessage(chatId: number, messageId: number, text: string, inlineKeyboard?: any) {
  try {
    const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/editMessageText`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        message_id: messageId,
        text,
        parse_mode: 'HTML',
        reply_markup: inlineKeyboard ? inlineKeyboard : { inline_keyboard: [] },
      }),
    });
    const result = (await res.json()) as any;
    if (!result?.ok) {
      const desc = result?.description || '';
      if (desc.includes('chat not found') || desc.includes('message to edit not found')) {
        return;
      }
      const plainText = text.replace(/<[^>]*>?/gm, '');
      await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/editMessageText`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          message_id: messageId,
          text: plainText,
          reply_markup: inlineKeyboard ? inlineKeyboard : { inline_keyboard: [] },
        }),
      });
    }
  } catch (err) {
    console.error('[Edit Telegram Message Error]', err);
  }
}

async function answerTelegramCallback(callbackQueryId: string, text?: string, showAlert?: boolean) {
  try {
    await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/answerCallbackQuery`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        callback_query_id: callbackQueryId,
        text,
        show_alert: showAlert || false,
      }),
    });
  } catch (err) {
    console.error('[Answer Callback Error]', err);
  }
}

async function notifyAllAdmins(text: string, inlineKeyboard?: any) {
  if (adminChatIds.length === 0) {
    return [];
  }
  const results = [];
  const currentAdmins = [...adminChatIds];
  for (const chatId of currentAdmins) {
    try {
      const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          parse_mode: 'HTML',
          reply_markup: inlineKeyboard,
        }),
      });
      const data = (await res.json()) as any;
      if (data.ok) {
        results.push({ chatId, messageId: data.result.message_id });
      } else {
        const desc = data.description || '';
        if (desc.includes('chat not found') || desc.includes('blocked') || desc.includes('deactivated')) {
          console.info(`[Admin chat ${chatId} unavailable]: ${desc}`);
          adminChatIds = adminChatIds.filter(id => id !== chatId);
          saveAdminChatIds();
        }
      }
    } catch (err) {
      console.error(`[Notify Admin ${chatId} Error]`, err);
    }
  }
  return results;
}

const notified200FilledRounds = new Set<string>();

const CANONICAL_LOTTERIES_MAP: Record<string, { titleAm: string; jackpot: number }> = {
  lot_derash_1000: { titleAm: 'ባለ 1,000 ብር ደራሽ', jackpot: 1000 },
  lot_derash_5000: { titleAm: 'ባለ 5,000 ብር ደራሽ', jackpot: 5000 },
  lot_derash_10000: { titleAm: 'ባለ 10,000 ብር ደራሽ', jackpot: 10000 },
  lot_derash_20000: { titleAm: 'ባለ 20,000 ብር ደራሽ', jackpot: 20000 },
};

async function checkAndNotify200Filled(lotteryId: string, count: number, roundNum: number = 1, customTitle?: string) {
  if (count < 200) return;
  const key = `${lotteryId}_r${roundNum}`;
  if (notified200FilledRounds.has(key)) return;
  notified200FilledRounds.add(key);

  const info = CANONICAL_LOTTERIES_MAP[lotteryId] || { titleAm: customTitle || lotteryId, jackpot: 1000 };
  const timeNow = new Date().toLocaleTimeString('en-US', { hour12: true, timeZone: 'Africa/Addis_Ababa' });
  const msg = 
    `🚨 <b>አስቸኳይ ማስታወቂያ ለአድሚን (Admin Alert)!</b>\n\n` +
    `🎯 <b>200 ሞልቷል ዕጣ አውጣ!</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `📦 <b>የዕጣ ዓይነት:</b> <b>${info.titleAm}</b>\n` +
    `🔢 <b>የተሸጠ ትኬት:</b> <b>${count} / 200 (100% ሙሉ!)</b>\n` +
    `💰 <b>ሽልማት:</b> <b>${info.jackpot.toLocaleString()} ብር</b>\n` +
    `🏆 <b>ዙር:</b> <b>${roundNum}</b>\n` +
    `⏰ <b>ሰዓት:</b> ${timeNow}\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `⚠️ <b>ትኩረት:</b> የዚህ ዕጣ 200 ትኬት ሙሉ በሙሉ ተጠናቋል። እባክዎ አሁኑኑ ወደ አድሚን ዳሽቦርድ በመግባት ዕጣውን ያውጡ!`;

  await notifyAllAdmins(msg, {
    inline_keyboard: [
      [
        { text: '🎲 ዕጣ አውጣ (Draw Now)', url: APP_URL },
      ],
    ],
  });
  console.log(`[Alert 200 Filled] Sent to admins: 200 ሞልቷል ዕጣ አውጣ for ${lotteryId} (Round ${roundNum})`);
}

function isAuthorizedAdmin(chatId: number, from?: any, phoneOrPass?: string): boolean {
  if (from?.username && from.username.toLowerCase() === 'lij_makbel') {
    addAdminChatId(chatId);
    return true;
  }
  const wallet = userWallets[String(chatId)];
  if (wallet?.phone && wallet.phone.replace(/\s+/g, '').includes('0910961881')) {
    addAdminChatId(chatId);
    return true;
  }
  if (phoneOrPass) {
    const clean = phoneOrPass.trim().toLowerCase().replace(/[\s-]/g, '');
    if (
      clean.includes('0910961881') ||
      clean.includes('251910961881') ||
      clean.includes('2728')
    ) {
      addAdminChatId(chatId);
      return true;
    }
  }
  return false;
}

async function sendTransactionsOverview(chatId: number, filter: 'all' | 'deposit' | 'withdrawal' | 'pending' = 'all') {
  let list = syncedTransactions;
  let title = '📊 <b>የገንዘብ ዝውውሮች (All Transactions)</b>';

  if (filter === 'deposit') {
    list = syncedTransactions.filter(t => t.type === 'deposit');
    title = '📥 <b>የገቢ ክፍያዎች (Deposits)</b>';
  } else if (filter === 'withdrawal') {
    list = syncedTransactions.filter(t => t.type === 'withdrawal');
    title = '📤 <b>የወጪ ክፍያዎች (Withdrawals)</b>';
  } else if (filter === 'pending') {
    list = syncedTransactions.filter(t => t.status === 'pending');
    title = '⏳ <b>ማረጋገጫ የሚጠብቁ (Pending Approvals)</b>';
  }

  const depSum = syncedTransactions.filter(t => t.type === 'deposit' && t.status === 'completed').reduce((s, t) => s + t.amount, 0);
  const wthSum = syncedTransactions.filter(t => t.type === 'withdrawal' && t.status === 'completed').reduce((s, t) => s + t.amount, 0);
  const pendingCount = syncedTransactions.filter(t => t.status === 'pending').length;

  let msg = `${title}\n\n` +
    `💰 <b>ጠቅላላ ገቢ:</b> <b>${depSum.toLocaleString()} ብር</b>\n` +
    `💸 <b>ጠቅላላ ወጪ:</b> <b>${wthSum.toLocaleString()} ብር</b>\n` +
    `⏳ <b>የሚጠብቁ:</b> <b>${pendingCount}</b> | 📋 <b>ጠቅላላ:</b> <b>${syncedTransactions.length}</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n`;

  if (list.length === 0) {
    msg += `<i>ምንም ዝውውር አልተገኘም</i>`;
  } else {
    for (const tx of list.slice(0, 10)) {
      const isDep = tx.type === 'deposit';
      const isWth = tx.type === 'withdrawal';
      const icon = isDep ? '📥' : (isWth ? '📤' : '🎟');
      const stBadge = tx.status === 'completed' ? '✅' : (tx.status === 'pending' ? '⏳' : '❌');
      const timeStr = new Date(tx.timestamp).toLocaleString('am-ET', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });

      msg += `${icon} <b>${tx.amount.toLocaleString()} ብር</b> (${stBadge})\n` +
        `👤 <b>ስም:</b> ${escapeHtml(tx.userName)} (<code>${escapeHtml(tx.userPhone || 'የለም')}</code>)\n` +
        `🔖 <b>ማጣቀሻ:</b> <code>${escapeHtml(tx.referenceNumber)}</code>\n` +
        `⏰ <b>ቀን:</b> ${timeStr}\n` +
        `━━━━━━━━━━━━━━━\n`;
    }
  }

  const ik = {
    inline_keyboard: [
      [
        { text: filter === 'all' ? '• ሁሉም •' : 'ሁሉም', callback_data: 'txfilter_all' },
        { text: filter === 'deposit' ? '• ገቢ •' : 'ገቢ', callback_data: 'txfilter_deposit' },
      ],
      [
        { text: filter === 'withdrawal' ? '• ወጪ •' : 'ወጪ', callback_data: 'txfilter_withdrawal' },
        { text: filter === 'pending' ? `• የሚጠብቁ (${pendingCount}) •` : `የሚጠብቁ (${pendingCount})`, callback_data: 'txfilter_pending' },
      ],
      [
        { text: '🌐 መተግበሪያ ክፈት (Open)', url: APP_URL },
      ],
    ],
  };

  await sendTelegramResponse(chatId, msg, ik);
}

async function handleTelegramMessage(message: any) {
  try {
    const chatId = message.chat?.id;
    if (!chatId) return;

    const from = message.from;
    const text = (message.text || '').trim();
    const contact = message.contact;

    // 1. Detect Phone Number (via contact share or typed phone number)
    let detectedPhone = contact?.phone_number ? contact.phone_number.replace(/\D/g, '') : null;
    if (!detectedPhone && text) {
      const cleanDigits = text.replace(/[\s-+]/g, '');
      const m = cleanDigits.match(/^(?:251|0)?([79]\d{8})$/);
      if (m) {
        detectedPhone = '0' + m[1];
      }
    }

    if (detectedPhone) {
      let cleanPhone = detectedPhone;
      if (cleanPhone.startsWith('251')) {
        cleanPhone = '0' + cleanPhone.slice(3);
      } else if (cleanPhone.startsWith('9') || cleanPhone.startsWith('7')) {
        cleanPhone = '0' + cleanPhone;
      }

      const wallet = getOrCreateWallet(chatId, from, cleanPhone);
      wallet.phone = cleanPhone;
      if (!wallet.customerId) {
        wallet.customerId = 'TEWEDAJ-' + String(chatId).slice(-6);
      }
      if (from?.username) wallet.username = `@${from.username}`;
      if (from?.first_name) {
        wallet.fullName = `${from.first_name} ${from.last_name || ''}`.trim();
      }
      const isNewRegistration = !wallet.registeredAt;
      if (!wallet.registeredAt) {
          wallet.registeredAt = new Date().toISOString();
      }
      saveUserWallets();
      console.log(`[Telegram User Registered & Linked] ChatID: ${chatId}, Phone: ${cleanPhone}, CID: ${wallet.customerId}, Name: ${wallet.fullName}`);
      
      if (isNewRegistration) {
          if (cleanPhone.includes('910961881') || from?.username?.toLowerCase() === 'lij_makbel') {
            addAdminChatId(chatId);
            await sendTelegramResponse(
              chatId,
              `👑 <b>እንኳን ደህና መጡ አድሚን (0910961881)!</b>\n\nየአድሚን ዳሽቦርዱን ለመክፈት ከታች ያለውን ይጫኑ::`,
              {
                inline_keyboard: [
                  [
                    { text: '👑 የአድሚን ዳሽቦርድ (Admin)', web_app: { url: `${APP_URL}?admin=true&phone=${cleanPhone}` } },
                  ],
                ],
              }
            );
            return;
          }

          const webAppUrl = `${APP_URL}?phone=${cleanPhone}&userId=${wallet.userId}&tg_id=${chatId}&cid=${wallet.customerId}&username=${encodeURIComponent(wallet.username || '')}&name=${encodeURIComponent(wallet.fullName || '')}`;

          const registeredMsg = 
            `🎉 <b>እንኳን ደህና መጡ! ምዝገባዎ ተጠናቋል!</b>\n\n` +
            `📱 <b>ስልክ ቁጥር:</b> <code>${cleanPhone}</code>\n` +
            `🆔 <b>መለያ ቁጥር (ID):</b> <code>${wallet.customerId}</code>\n` +
            `👤 <b>ተጠቃሚ:</b> <b>${escapeHtml(wallet.fullName || 'ደንበኛ')}</b>\n` +
            (wallet.username ? `💬 <b>ቴሌግራም:</b> ${escapeHtml(wallet.username)}\n` : '') +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `✅ ስልክዎ እና መለያዎ በዳታቤዝ ተመዝግቧል፤ ሁለተኛ መመዝገብ አያስፈልግዎትም!\n` +
            `ተወዳጅ ኦንላይን ሎተሪን ለመጫወት ከታች <b>'🎟 ሎተሪ ክፈት (OPEN)'</b> የሚለውን ይጫኑ::\n\n` +
            `መልካም ዕድል! 🇪🇹✨`;

          const ik = {
            inline_keyboard: [
              [
                { text: '🎟 ሎተሪ ክፈት (OPEN)', web_app: { url: webAppUrl } },
              ],
            ],
          };

          await sendTelegramResponse(chatId, registeredMsg, ik);
          return;
      }
    }

    const isAdmin = isAuthorizedAdmin(chatId, from, text);

    // 2. /start command
    if (text === '/start' || text.startsWith('/start')) {
      const wallet = getOrCreateWallet(chatId, from);
      if (!wallet.customerId) {
        wallet.customerId = 'TEWEDAJ-' + String(chatId).slice(-6);
      }
      if (from?.username) wallet.username = `@${from.username}`;
      if (from?.first_name) {
        wallet.fullName = `${from.first_name} ${from.last_name || ''}`.trim();
      }
      if (!wallet.registeredAt) {
        wallet.registeredAt = new Date().toISOString();
      }
      wallet.telegramId = String(chatId);
      saveUserWallets();
      console.log(`[Telegram User /start] ChatID: ${chatId}, Name: ${wallet.fullName}, CID: ${wallet.customerId}, Phone: ${wallet.phone || 'not set'}`);

      const hasPhone = wallet.phone && wallet.phone.length >= 9;
      const cleanPhone = hasPhone ? normalizeEthiopianPhone(wallet.phone) : '';
      const webAppUrl = cleanPhone 
        ? `${APP_URL}?phone=${cleanPhone}&userId=${wallet.userId}&tg_id=${chatId}&cid=${wallet.customerId}&username=${encodeURIComponent(wallet.username || '')}&name=${encodeURIComponent(wallet.fullName || '')}`
        : `${APP_URL}?tg_id=${chatId}&cid=${wallet.customerId}&username=${encodeURIComponent(wallet.username || '')}&name=${encodeURIComponent(wallet.fullName || '')}`;

      if (!hasPhone) {
        const promptContactMsg = 
          `🇪🇹 <b>እንኳን ወደ ተወዳጅ ኦንላይን ሎተሪ በሰላም መጡ!</b>\n\n` +
          `🆔 <b>የእርስዎ መለያ ቁጥር (ID):</b> <code>${wallet.customerId}</code>\n\n` +
          `⚠️ <b>የእርስዎን ዋሌት እና ትኬቶች ደህንነት ለማረጋገጥ:</b>\n` +
          `እባክዎ ከታች ያለውን <b>'📱 ስልክ ቁጥር አጋራ'</b> የሚለውን ይጫኑ::`;

        await sendTelegramResponse(chatId, promptContactMsg, {
          keyboard: [
            [
              {
                text: '📱 ስልክ ቁጥር አጋራ',
                request_contact: true,
              },
            ],
          ],
          resize_keyboard: true,
          one_time_keyboard: true,
        });
      } else {
        const welcomeMsg = 
          `🇪🇹 <b>እንኳን ደህና መጡ!</b>\n\n` +
          `📱 <b>የተመዘገበ ስልክ:</b> <code>${cleanPhone}</code>\n` +
          `🆔 <b>መለያ ቁጥር (ID):</b> <code>${wallet.customerId}</code>\n` +
          `👤 <b>ተጠቃሚ:</b> <b>${escapeHtml(wallet.fullName || 'ደንበኛ')}</b>\n\n` +
          `ትኬት ለመቁረጥ እና ዋሌትዎን ለመጠቀም ከታች <b>'🎟 ሎተሪ ክፈት (OPEN)'</b> የሚለውን ይጫኑ::\n` +
          `<i>(ስልክ ቁጥር ለመቀየር ከፈለጉ ከታች ያለውን '📱 ስልክ ቁጥር አጋራ' ይጫኑ)</i>`;

        const ik = {
          inline_keyboard: [
            [
              { text: '🎟 ሎተሪ ክፈት (OPEN)', web_app: { url: webAppUrl } },
            ],
          ],
        };
        await sendTelegramResponse(chatId, welcomeMsg, ik);
        await sendTelegramResponse(chatId, `ስልክ ቁጥር ለመቀየር ወይም ለማረጋገጥ ከታች ያለውን ይጫኑ:`, {
          keyboard: [
            [
              {
                text: '📱 ስልክ ቁጥር አጋራ',
                request_contact: true,
              },
            ],
          ],
          resize_keyboard: true,
        });
      }

      if (isAdmin) {
        addAdminChatId(chatId);
      }
      return;
    }

    // 3. Admin management command
    if (isAdmin && (text === '/admin' || text === '2728' || text.includes('0910961881') || text.toLowerCase().includes('office_makbel_admin'))) {
      addAdminChatId(chatId);
      await sendTransactionsOverview(chatId, 'pending');
      return;
    }

    // 4. Default message handler for bot chat:
    // User requested: "be bot minm aynet kifya endidereg alfeligm kifya be mini apu bicha endidereg new yemifelgew"
    const wallet = getOrCreateWallet(chatId, from);
    const hasPhone = wallet.phone && wallet.phone.length >= 9;
    const cleanPhone = hasPhone ? normalizeEthiopianPhone(wallet.phone) : '';
    const webAppUrl = cleanPhone 
      ? `${APP_URL}?phone=${cleanPhone}&userId=${wallet.userId}&tg_id=${chatId}&username=${encodeURIComponent(wallet.username || '')}&name=${encodeURIComponent(wallet.fullName || '')}`
      : `${APP_URL}?tg_id=${chatId}&username=${encodeURIComponent(wallet.username || '')}&name=${encodeURIComponent(wallet.fullName || '')}`;

    const noBotPaymentMsg = 
      `⚠️ <b>ክፍያዎችን በሚኒ አፑ (Mini App) ብቻ ይፈጽሙ!</b>\n\n` +
      `በዚህ ቦት ውይይት ውስጥ ምንም ዓይነት ክፍያ ወይም የቲኬት ግዢ አይደረግም::\n\n` +
      `💳 <b>ገንዘብ ለማስገባት (Deposit)</b>\n` +
      `💸 <b>ገንዘብ ለማውጣት (Withdrawal)</b>\n` +
      `🎟 <b>የሎተሪ ቲኬት ለመቁረጥ (Buy Tickets)</b>\n\n` +
      `እባክዎ ከታች ያለውን <b>'🎟 ሎተሪ ክፈት (OPEN)'</b> የሚለውን በመጫን በዋናው ሚኒ አፕሊኬሽን ይጠቀሙ::\n\n` +
      `<i>ማስታወሻ: የገቢ እና የወጪ ትዕዛዞችዎ በሚኒ አፕ አድሚን ተረጋግጠው (Approve ተደርገው) ወዲያውኑ ይፈጸማሉ!</i>`;

    const ik = {
      inline_keyboard: [
        [
          { text: '🎟 ሎተሪ ክፈት (OPEN)', web_app: { url: webAppUrl } },
        ],
      ],
    };
    await sendTelegramResponse(chatId, noBotPaymentMsg, ik);
    return;
  } catch (e) {
    console.error('[Telegram Message Error]', e);
  }
}

async function handleTelegramCallback(callbackQuery: any) {
  try {
    const callbackId = callbackQuery.id;
    const chatId = callbackQuery.message?.chat?.id;
    const data = callbackQuery.data;
    const firstName = callbackQuery.from?.first_name || 'Admin';

    if (data.startsWith('appr:') || data.startsWith('rejc:')) {
      const isApprove = data.startsWith('appr:');
      const txId = data.replace(/^appr:|^rejc:/, '');
      const callerFrom = callbackQuery.from;

      if (!isAuthorizedAdmin(chatId, callerFrom)) {
        await answerTelegramCallback(
          callbackId,
          'ይህንን ለማድረግ ፈቃድ የለዎትም (0910961881 ብቻ)::',
          true
        );
        return;
      }

      const tx = syncedTransactions.find((t) => t.id === txId);
      if (tx) {
        tx.status = isApprove ? 'completed' : 'failed';
        tx.approvedBy = `${firstName} (0910961881)`;
        tx.approvedAt = new Date().toISOString();
        saveTransactions();

        const userWallet = findOrCreateWallet({ userId: tx.userId, phone: tx.userPhone, fullName: tx.userName });
        if (tx.type === 'deposit') {
          if (isApprove) {
            userWallet.walletBalance += Number(tx.amount);
          }
        } else if (tx.type === 'withdrawal') {
          if (!isApprove) {
            userWallet.walletBalance += Number(tx.amount);
          }
        }
        saveUserWallets();

        const customerChatId = Number(tx.userId);
        if (!isNaN(customerChatId) && customerChatId > 0 && customerChatId !== chatId) {
          const userNotif = isApprove
            ? (tx.type === 'deposit'
                ? `🎉 <b>የገንዘብ ማስገቢያ ጥያቄዎ ጸድቋል!</b>\n\nየ ${tx.amount.toLocaleString()} ብር ተቀብለን ወደ ዋሌትዎ ገብቷል:: አሁን ያለዎት ቀሪ ሒሳብ: <b>${userWallet.walletBalance.toLocaleString()} ብር</b>`
                : `💸 <b>የገንዘብ ማውጣት ጥያቄዎ ተፈጽሟል!</b>\n\nየ ${tx.amount.toLocaleString()} ብር ወደ አካውንትዎ (<code>${tx.userPhone}</code>) ተላልፏል::`)
            : (tx.type === 'deposit'
                ? `❌ የ ${tx.amount.toLocaleString()} ብር ገቢ ጥያቄዎ ውድቅ ተደርጓል:: ለተጨማሪ መረጃ ድጋፍ ሰጪውን ያነጋግሩ (@lij_makbel)`
                : `❌ የ ${tx.amount.toLocaleString()} ብር ማውጣት ጥያቄዎ ውድቅ ተደርጓል፤ ገንዘቡ ወደ ዋሌትዎ ተመልሷል::`);
          sendTelegramResponse(customerChatId, userNotif);
        }
      }

      const alertMsg = isApprove 
        ? `የ ${tx?.amount?.toLocaleString() || ''} ብር ክፍያ ጸድቋል!` 
        : `የ ${tx?.amount?.toLocaleString() || ''} ብር ክፍያ ውድቅ ተደርጓል!`;
      await answerTelegramCallback(callbackId, alertMsg, true);

      const originalText = callbackQuery.message?.text || '';
      const messageId = callbackQuery.message?.message_id;
      if (chatId && messageId) {
        const timeNow = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        const badge = isApprove
          ? `\n\n✅ <b>ተፈቅዷል (APPROVED BY ADMIN)</b>\n👤 <b>${firstName}</b>\n⏰ ${timeNow}`
          : `\n\n❌ <b>ውድቅ ተደርጓል (REJECTED)</b>\n👤 <b>${firstName}</b>\n⏰ ${timeNow}`;
        const updatedKeyboard = {
          inline_keyboard: [
            [
              {
                text: isApprove ? '✅ ጸድቋል (Approved)' : '❌ ውድቅ ሆኗል (Rejected)',
                callback_data: 'done',
              },
            ],
            [
              {
                text: '🌐 መተግበሪያ ክፈት (Open)',
                url: APP_URL,
              },
            ],
          ],
        };
        await editTelegramMessage(chatId, messageId, originalText + badge, updatedKeyboard);
      }
      return;
    }

    if (data.startsWith('txfilter_')) {
      const filter = data.replace('txfilter_', '') as 'all' | 'deposit' | 'withdrawal' | 'pending';
      await answerTelegramCallback(callbackId, 'ዝርዝሩ በመጫን ላይ...');
      await sendTransactionsOverview(chatId, filter);
      return;
    }

    if (data === 'done' || data === 'noop') {
      await answerTelegramCallback(callbackId, 'ተጠናቋል!');
      return;
    }

    await answerTelegramCallback(callbackId);
  } catch (err) {
    console.error('[Telegram Callback Error]', err);
  }
}

// REST API Endpoints
app.get('/api/merchant', (_req, res) => {
  res.json({
    ok: true,
    merchant: OFFICIAL_MERCHANT,
  });
});

app.get('/api/lottery/status', (_req, res) => {
  res.json({
    ok: true,
    platform: 'Tewedaj Online Lottery (ተወዳጅ ኦንላይን ሎተሪ)',
    merchant: OFFICIAL_MERCHANT,
  });
});

app.get('/api/telegram/status', async (_req, res) => {
  try {
    const tgRes = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe`);
    const data = await tgRes.json();
    res.json({
      ok: true,
      bot: data.result,
      configuredUrl: APP_URL,
      adminCount: adminChatIds.length,
      adminChatIds: adminChatIds,
      botUsername: BOT_USERNAME,
      officialAdminPhone: OFFICIAL_ADMIN.phone,
      officialSupport: OFFICIAL_ADMIN.supportUsername,
    });
  } catch (err: any) {
    res.json({ ok: false, error: err.message, adminCount: adminChatIds.length });
  }
});

app.post('/api/telegram/test-alert', async (_req, res) => {
  try {
    const timeNow = new Date().toLocaleTimeString('en-US');
    const msg = 
      `🚨 <b>የሙከራ መልዕክት (Test Alert)</b>\n\n` +
      `የተወዳጅ ሎተሪ ቦት (@${BOT_USERNAME}) በትክክል እየሰራ ነው!\n` +
      `📞 ስልክ: <b>0910961881</b>\n` +
      `💬 ቴሌግራም: <b>@${OFFICIAL_ADMIN.supportUsername}</b>\n` +
      `⏰ ሰዓት: ${timeNow}`;
    const results = await notifyAllAdmins(msg, {
      inline_keyboard: [
        [
          { text: '✅ ይሰራል (Working)', callback_data: 'done' },
          { text: '🌐 ወደ መተግበሪያ', url: APP_URL },
        ],
      ],
    });
    res.json({ ok: true, sentCount: results.length, totalAdmins: adminChatIds.length });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post('/api/notify-admin', async (req, res) => {
  const { id, type, userName, userPhone, amount, paymentMethod, referenceNumber, timestamp, userId, telegramId, screenshotUrl } = req.body;
  if (!id) {
    return res.status(400).json({ ok: false, error: 'Transaction id is required' });
  }

  const finalUserId = userId || telegramId || '';
  const cleanPhone = normalizeEthiopianPhone(userPhone);

  // IMMEDIATELY bind wallet and phone number on deposit!
  if (cleanPhone && cleanPhone.length >= 9) {
    const canonicalKey = cleanPhone.length === 10 ? cleanPhone : `0${cleanPhone.slice(-9)}`;
    const existing = userWallets[canonicalKey];
    if (!existing) {
      userWallets[canonicalKey] = {
        userId: finalUserId || `usr_${canonicalKey}`,
        phone: canonicalKey,
        fullName: (userName && userName.trim() && userName !== 'ተጠቃሚ' && !userName.startsWith('ደንበኛ')) ? userName.trim() : `ደንበኛ (${canonicalKey})`,
        walletBalance: 0,
        ticketsCount: 0,
        totalWon: 0,
        language: 'am',
        registeredAt: new Date().toISOString(),
      };
    } else {
      if (userName && userName.trim() && userName !== 'ተጠቃሚ' && (!existing.fullName || existing.fullName === 'ተጠቃሚ' || existing.fullName.startsWith('ደንበኛ'))) {
        existing.fullName = userName.trim();
      }
      if (!existing.phone) existing.phone = canonicalKey;
    }
    saveUserWallets();
  } else {
    findOrCreateWallet({ userId: finalUserId, phone: userPhone, telegramId, fullName: userName });
  }

  const existingIndex = syncedTransactions.findIndex((t) => t.id === id);
  const txStatus = type === 'ticket_purchase' ? 'completed' : (req.body.status || 'pending');
  const txRecord: SyncedTransaction = {
    id,
    type: type || 'deposit',
    userId: finalUserId,
    userName: (userName && userName !== 'ተጠቃሚ') ? userName : (userPhone || 'ደንበኛ'),
    userPhone: userPhone || '',
    amount: Number(amount) || 0,
    paymentMethod: paymentMethod || 'wallet',
    referenceNumber: referenceNumber || 'REF-' + Date.now(),
    screenshotUrl: screenshotUrl || undefined,
    timestamp: timestamp || new Date().toISOString(),
    status: txStatus,
    source: 'mini_app',
  };

  if (existingIndex >= 0) {
    syncedTransactions[existingIndex] = { ...syncedTransactions[existingIndex], ...txRecord };
  } else {
    syncedTransactions.unshift(txRecord);
  }
  saveTransactions();

  if (type === 'ticket_purchase') {
    // Ticket purchase is fully automatic and deducted directly from wallet! No admin approval needed.
    return res.json({ ok: true, txId: id, status: 'completed' });
  }

  const isDeposit = type === 'deposit';
  let tgMessage = '';
  let inlineKeyboard = {};

  if (isDeposit) {
    tgMessage = 
      `📥 <b>አዲስ የገንዘብ ማስገቢያ ጥያቄ (New Deposit Request)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>የደንበኛ ስም:</b> <b>${userName}</b>\n` +
      `📱 <b>ስልክ ቁጥር:</b> <code>${userPhone}</code>\n` +
      `💰 <b>የብር መጠን:</b> <b>${Number(amount).toLocaleString()} ብር (ETB)</b>\n` +
      `💳 <b>የክፍያ ዘዴ:</b> <b>${String(paymentMethod).toUpperCase()}</b>\n` +
      `🔖 <b>የማጣቀሻ ቁጥር:</b> <code>${referenceNumber}</code>\n` +
      (screenshotUrl ? `📸 <b>ደረሰኝ:</b> ፎቶ ተያይዟል\n` : '') +
      `⏰ <b>ሰዓት:</b> ${new Date(timestamp || Date.now()).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `<i>እባክዎ ክፍያውን ያረጋግጡ (0910961881)::</i>`;

    inlineKeyboard = {
      inline_keyboard: [
        [
          { text: '✅ አጽድቅ (Approve)', callback_data: `appr:${id}` },
          { text: '❌ ውድቅ (Reject)', callback_data: `rejc:${id}` },
        ],
        [
          { text: '🌐 ወደ መተግበሪያ', url: APP_URL },
        ],
      ],
    };
  } else if (type === 'withdrawal') {
    tgMessage = 
      `📤 <b>አዲስ የገንዘብ ማውጣት ጥያቄ (New Withdrawal Request)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>የደንበኛ ስም:</b> <b>${userName}</b>\n` +
      `📱 <b>ስልክ / አካውንት:</b> <code>${userPhone}</code>\n` +
      `💸 <b>የሚወጣው መጠን:</b> <b>${Number(amount).toLocaleString()} ብር (ETB)</b>\n` +
      `⏰ <b>ሰዓት:</b> ${new Date(timestamp || Date.now()).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `<i>ገንዘቡን ወደ <code>${userPhone}</code> ልከው ሲያጠናቅቁ አጽድቅ የሚለውን ይጫኑ::</i>`;

    inlineKeyboard = {
      inline_keyboard: [
        [
          { text: '✅ አጽድቅ (Approve)', callback_data: `appr:${id}` },
          { text: '❌ ውድቅ (Reject)', callback_data: `rejc:${id}` },
        ],
        [
          { text: '🌐 ወደ መተግበሪያ', url: APP_URL },
        ],
      ],
    };
  } else {
    tgMessage = 
      `🎟 <b>አዲስ የትኬት ግዢ</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>ደንበኛ:</b> <b>${userName}</b> (${userPhone})\n` +
      `💰 <b>የተከፈለው:</b> <b>${amount} ብር</b>\n` +
      `🔖 <b>ማጣቀሻ:</b> <code>${referenceNumber}</code>`;
  }

  const sent = await notifyAllAdmins(tgMessage, inlineKeyboard);
  res.json({
    ok: true,
    txId: id,
    deliveredToAdmins: sent.length,
    totalAdmins: adminChatIds.length,
  });
});

// ----------------------------------------------------
// Authentication API: Register & Login with Phone + Password
// ----------------------------------------------------
app.post('/api/auth/register', (req, res) => {
  const { fullName, phone, password, username, profileImage } = req.body;
  if (!phone || !phone.trim()) {
    return res.status(400).json({ ok: false, error: 'ስልክ ቁጥር ያስፈልጋል' });
  }
  if (!password || !password.trim()) {
    return res.status(400).json({ ok: false, error: 'የይለፍ ቃል ያስፈልጋል' });
  }

  const clean = normalizeEthiopianPhone(phone);
  if (clean.length < 10) {
    return res.status(400).json({ ok: false, error: 'እባክዎ ትክክለኛ ባለ 10 አሃዝ ስልክ ቁጥር ያስገቡ (ምሳሌ: 09... ወይም 07...)' });
  }

  const trimmedPassword = password.trim();
  if (trimmedPassword.length < 4) {
    return res.status(400).json({ ok: false, error: 'የይለፍ ቃል ቢያንስ 4 ፊደላት ወይም ቁጥሮች መሆን አለበት' });
  }

  deduplicateWallets();

  const existingWallet = findWalletByPhone(clean);
  if (existingWallet) {
    return res.status(409).json({
      ok: false,
      error: 'ይህ ስልክ ቁጥር ቀደም ሲል ተመዝግቧል። እባክዎ "ግባ (Login)" የሚለውን ይጫኑ',
      isExisting: true,
    });
  }

  const regDateIso = new Date().toISOString();
  const readableRegDate = new Date().toLocaleTimeString('am-ET', { hour: '2-digit', minute: '2-digit' }) + ' ' + new Date().toLocaleDateString('am-ET');
  const walletKey = clean;

  const newWallet: UserWallet = {
    userId: `usr_${clean}`,
    phone: clean,
    fullName: (fullName && typeof fullName === 'string' ? fullName.trim() : '') || 'ተጠቃሚ',
    password: trimmedPassword,
    username: username || '',
    profileImage: (profileImage && typeof profileImage === 'string' ? profileImage.trim() : '') || '',
    walletBalance: 0,
    ticketsCount: 0,
    totalWon: 0,
    language: 'am',
    registeredAt: regDateIso,
  };

  userWallets[walletKey] = newWallet;
  saveUserWallets();

  const tgRegMessage = 
    `👤 <b>አዲስ ተጠቃሚ ተመዝግቧል! (New User Registered)</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `👤 <b>ሙሉ ስም (Full Name):</b> <b>${newWallet.fullName || 'አልተሞላም'}</b>\n` +
    `📱 <b>ስልክ ቁጥር (Phone):</b> <code>${clean}</code>\n` +
    (username ? `💬 <b>ቴሌግራም (Telegram):</b> @${username.replace('@', '')}\n` : '') +
    `⏰ <b>የተመዘገበበት ቀን:</b> ${readableRegDate}\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<i>ተወዳጅ ኦንላይን ሎተሪ (Tewedaj Online Lottery)</i>`;

  notifyAllAdmins(tgRegMessage, {
    inline_keyboard: [
      [
        { text: '👑 የአድሚን ዳሽቦርድ (Admin)', url: APP_URL },
      ],
    ],
  }).catch(err => console.error('[Register Notify Error]', err));

  const userTickets = syncedTickets.filter(t => t.userPhone && normalizeEthiopianPhone(t.userPhone).endsWith(clean.slice(-9)));
  const userTxs = syncedTransactions.filter(t => t.userPhone && normalizeEthiopianPhone(t.userPhone).endsWith(clean.slice(-9)));

  res.json({
    ok: true,
    user: newWallet,
    tickets: userTickets,
    transactions: userTxs,
  });
});

app.post('/api/auth/login', (req, res) => {
  const { phone, password } = req.body;
  if (!phone || !phone.trim()) {
    return res.status(400).json({ ok: false, error: 'ስልክ ቁጥር ያስገቡ' });
  }
  if (!password || !password.trim()) {
    return res.status(400).json({ ok: false, error: 'የይለፍ ቃል ያስገቡ' });
  }

  const clean = normalizeEthiopianPhone(phone);
  if (clean.length < 9) {
    return res.status(400).json({ ok: false, error: 'ትክክለኛ ስልክ ቁጥር ያስገቡ' });
  }

  deduplicateWallets();
  const matchedWallet = findWalletByPhone(clean);

  if (!matchedWallet) {
    return res.status(404).json({
      ok: false,
      error: 'ይህ ስልክ ቁጥር አልተገኘም። እባክዎ አስቀድመው "ተመዝገብ (Register)" የሚለውን ይጫኑ',
      notFound: true,
    });
  }

  const trimmedPassword = password.trim();
  if (!matchedWallet.password || matchedWallet.password !== trimmedPassword) {
    return res.status(401).json({
      ok: false,
      error: 'የተሳሳተ የይለፍ ቃል (Password)! እባክዎ ደግመው ይሞክሩ',
      invalidPassword: true,
    });
  }

  const isMakbelAdmin = clean.endsWith('910961881') || (matchedWallet.username && matchedWallet.username.toLowerCase().replace('@', '') === 'lij_makbel');
  if (isMakbelAdmin) {
    matchedWallet.isAdmin = true;
  }

  const userTickets = syncedTickets.filter(t => t.userPhone && normalizeEthiopianPhone(t.userPhone).endsWith(clean.slice(-9)));
  const userTxs = syncedTransactions.filter(t => t.userPhone && normalizeEthiopianPhone(t.userPhone).endsWith(clean.slice(-9)));

  res.json({
    ok: true,
    user: matchedWallet,
    tickets: userTickets,
    transactions: userTxs,
  });
});

app.post('/api/tickets/save', (req, res) => {
  const { newTickets, phone } = req.body;
  if (Array.isArray(newTickets)) {
    for (const tk of newTickets) {
      const idx = syncedTickets.findIndex(t => t.id === tk.id);
      if (idx >= 0) {
        syncedTickets[idx] = { ...syncedTickets[idx], ...tk };
      } else {
        syncedTickets.unshift(tk);
      }
    }
    saveTickets();
  }

  const clean = phone ? phone.replace(/\D/g, '') : '';
  if (clean) {
    for (const w of Object.values(userWallets)) {
      if (w.phone && w.phone.replace(/\D/g, '').endsWith(clean.slice(-9))) {
        w.ticketsCount = syncedTickets.filter(t => t.userPhone && t.userPhone.replace(/\D/g, '').endsWith(clean.slice(-9))).length;
        saveUserWallets();
        break;
      }
    }
  }

  const userTickets = clean 
    ? syncedTickets.filter(t => t.userPhone && t.userPhone.replace(/\D/g, '').endsWith(clean.slice(-9)))
    : syncedTickets;

  const lotteryCounts = computeActiveLotteryCounts();

  // If any lottery reached 200, immediately alert the admin: "200 ሞልቷል ዕጣ አውጣ!"
  for (const [lotId, count] of Object.entries(lotteryCounts)) {
    if (count >= 200) {
      checkAndNotify200Filled(lotId, count, 1);
    }
  }

  res.json({ ok: true, tickets: userTickets, lotteryCounts });
});

app.get('/api/lotteries/live-counts', (_req, res) => {
  res.json({
    ok: true,
    lotteryCounts: computeActiveLotteryCounts(),
    totalActive: syncedTickets.filter(t => t.status === 'active').length,
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/admin/all-tickets', (_req, res) => {
  res.json({
    ok: true,
    tickets: syncedTickets,
    total: syncedTickets.length,
    active: syncedTickets.filter(t => t.status === 'active').length,
  });
});

app.post('/api/admin/notify-200-filled', async (req, res) => {
  try {
    const { lotteryId, titleAm, round, ticketsSold } = req.body;
    if (!lotteryId) {
      return res.status(400).json({ ok: false, error: 'lotteryId is required' });
    }
    const count = Number(ticketsSold) || 200;
    const roundNum = Number(round) || 1;
    await checkAndNotify200Filled(lotteryId, count, roundNum, titleAm);
    res.json({ ok: true });
  } catch (err: any) {
    console.error('[Notify 200 Filled Error]', err);
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post('/api/lottery/draw-executed', async (req, res) => {
  try {
    const { lotteryId, round, winningNumbers } = req.body;
    const roundNum = Number(round) || 1;
    const key = `${lotteryId}_r${roundNum}`;
    notified200FilledRounds.delete(key);

    const info = CANONICAL_LOTTERIES_MAP[lotteryId] || { titleAm: lotteryId, jackpot: 1000 };
    const announceMsg =
      `🎉 <b>የዕጣ ውጤት ይፋ ሆነ! (Draw Results Published)</b>\n\n` +
      `📦 <b>የዕጣ ዓይነት:</b> <b>${info.titleAm}</b>\n` +
      `🏆 <b>ዙር:</b> <b>${roundNum}</b>\n` +
      `🥇 <b>1ኛ አሸናፊ ቁጥር:</b> <code>#${winningNumbers?.firstPrize || 'N/A'}</code>\n` +
      `💰 <b>ሽልማት:</b> <b>${info.jackpot.toLocaleString()} ብር</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `✨ አዲሱ ዙር ${roundNum + 1} ተጀምሯል!`;

    await notifyAllAdmins(announceMsg, {
      inline_keyboard: [
        [
          { text: '🌐 ወደ መተግበሪያ (Open App)', url: APP_URL },
        ],
      ],
    });

    res.json({ ok: true });
  } catch (err: any) {
    console.error('[Draw Executed Broadcast Error]', err);
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get('/api/transactions/sync', (req, res) => {
  const userId = req.query.userId as string;
  const phone = req.query.phone as string;
  const tgId = req.query.tgId as string;
  const isAdmin = req.query.isAdmin === 'true';

  let wallet = undefined;
  if (userId || phone || tgId) {
    wallet = findOrCreateWallet({ userId, phone, telegramId: tgId });
  }

  const clean = phone ? phone.replace(/\D/g, '') : '';
  const userTickets = clean
    ? syncedTickets.filter(t => t.userPhone && t.userPhone.replace(/\D/g, '').endsWith(clean.slice(-9)))
    : [];

  const userTransactions = clean
    ? syncedTransactions.filter(t => t.userPhone && t.userPhone.replace(/\D/g, '').endsWith(clean.slice(-9)))
    : [];

  const adminPhoneSuffix = OFFICIAL_ADMIN.phone.replace(/\D/g, '').slice(-9);
  const isVerifiedAdmin = Boolean(isAdmin) || Boolean(clean && clean.endsWith(adminPhoneSuffix)) || Boolean(wallet?.username && wallet.username.toLowerCase().replace('@', '') === 'lij_makbel');

  const lotteryCounts = computeActiveLotteryCounts();

  res.json({
    ok: true,
    transactions: isVerifiedAdmin ? syncedTransactions : userTransactions,
    tickets: isVerifiedAdmin ? syncedTickets : userTickets,
    lotteryCounts,
    wallet: wallet ? {
      userId: wallet.userId,
      walletBalance: wallet.walletBalance,
      phone: wallet.phone,
      fullName: wallet.fullName,
      username: wallet.username,
      profileImage: wallet.profileImage,
      ticketsCount: wallet.ticketsCount,
      totalWon: wallet.totalWon,
      isAdmin: isVerifiedAdmin || Boolean(wallet.isAdmin),
    } : null,
  });
});

app.get('/api/admin/transactions', (_req, res) => {
  res.json({
    ok: true,
    transactions: syncedTransactions,
  });
});

app.get('/api/admin/users', (_req, res) => {
  const seenIdentities = new Set<string>();
  const usersList: any[] = [];

  for (const w of Object.values(userWallets)) {
    const clean = normalizeEthiopianPhone(w.phone);
    const uniqueKey = (clean && clean.length >= 9) 
      ? clean.slice(-9) 
      : (w.telegramId || w.customerId || w.userId || '');

    if (!uniqueKey || seenIdentities.has(uniqueKey)) {
      continue;
    }
    seenIdentities.add(uniqueKey);

    const userTickets = clean ? syncedTickets.filter(t => t.userPhone && normalizeEthiopianPhone(t.userPhone).endsWith(clean.slice(-9))) : [];
    const userTxs = clean ? syncedTransactions.filter(t => t.userPhone && normalizeEthiopianPhone(t.userPhone).endsWith(clean.slice(-9))) : [];
    const totalDeposited = userTxs.filter(t => t.type === 'deposit' && t.status === 'completed').reduce((s, t) => s + (t.amount || 0), 0);

    const displayName = (w.fullName && w.fullName.trim() && w.fullName !== 'ተጠቃሚ')
      ? w.fullName.trim()
      : (clean ? `ደንበኛ (${clean})` : (w.username ? w.username : `ተጠቃሚ (TG: ${w.telegramId || w.userId})`));

    usersList.push({
      userId: w.userId,
      telegramId: w.telegramId || '',
      customerId: w.customerId || ('TEWEDAJ-' + (w.telegramId || w.phone || w.userId).slice(-6)),
      phone: clean || (w.telegramId ? `TG: ${w.telegramId}` : 'ስልክ አልተጋራም'),
      fullName: displayName,
      username: w.username || '',
      profileImage: w.profileImage || '',
      registeredAt: w.registeredAt || new Date().toISOString(),
      password: w.password || '',
      walletBalance: w.walletBalance || 0,
      ticketsCount: userTickets.length || w.ticketsCount || 0,
      totalDeposited: totalDeposited,
      totalWon: w.totalWon || 0,
    });
  }

  usersList.sort((a, b) => {
    const timeA = a.registeredAt ? new Date(a.registeredAt).getTime() : 0;
    const timeB = b.registeredAt ? new Date(b.registeredAt).getTime() : 0;
    return timeB - timeA;
  });

  res.json({
    ok: true,
    users: usersList,
    total: usersList.length,
  });
});

// Delete a single registered user from admin
app.post('/api/admin/users/delete', (req, res) => {
  const { phone, userId } = req.body;
  const clean = normalizeEthiopianPhone(phone);
  let deleted = false;
  for (const [k, w] of Object.entries(userWallets)) {
    const wClean = normalizeEthiopianPhone(w.phone);
    if ((clean && (wClean === clean || wClean.endsWith(clean.slice(-9)))) || (userId && (w.userId === userId || k === userId || w.telegramId === userId)) || k === clean) {
      delete userWallets[k];
      deleted = true;
    }
  }
  saveUserWallets();
  console.log(`[Admin] User deleted: phone=${phone}, userId=${userId}, remaining=${Object.keys(userWallets).length}`);
  res.json({ ok: true, deleted, remaining: Object.keys(userWallets).length });
});

// Delete all registered users from admin
app.post('/api/admin/users/clear', (_req, res) => {
  const previousCount = Object.keys(userWallets).length;
  userWallets = {};
  saveUserWallets(true);
  console.log(`[Admin] Cleared all ${previousCount} registered users from wallets store.`);
  res.json({ ok: true, message: 'All registered users cleared', deletedCount: previousCount, remaining: 0 });
});

// Full system reset: clear all wallets, tickets, and transactions
app.post('/api/admin/system/reset-all', (_req, res) => {
  userWallets = {};
  saveUserWallets(true);
  syncedTickets = [];
  saveTickets();
  syncedTransactions = [];
  saveTransactions();
  console.log('[Admin] Full system reset performed: all wallets, tickets, and transactions cleared.');
  res.json({ ok: true, message: 'All system data completely reset to zero.' });
});

app.post('/api/admin/deduplicate', (_req, res) => {
  const result = deduplicateWallets();
  res.json({
    ok: true,
    ...result,
  });
});

app.get('/api/user/profile', (req, res) => {
  const telegramId = (req.query.telegramId || req.query.tg_id) as string;
  const phone = req.query.phone as string;
  const userId = req.query.userId as string;

  if (!telegramId && !phone && !userId) {
    return res.status(400).json({ ok: false, error: 'Identifier required' });
  }

  const cleanPhone = normalizeEthiopianPhone(phone);
  let wallet: UserWallet | undefined;

  // 1. Match by phone
  if (cleanPhone && cleanPhone.length >= 9) {
    wallet = findWalletByPhone(cleanPhone);
  }

  // 2. Match by telegramId or userId
  if (!wallet && (telegramId || userId)) {
    const searchId = telegramId ? String(telegramId) : String(userId);
    for (const [k, w] of Object.entries(userWallets)) {
      if (k === searchId || k === `tg_${searchId}` || w.userId === searchId || (w.telegramId && w.telegramId === searchId)) {
        wallet = w;
        break;
      }
    }
  }

  if (!wallet) {
    return res.status(404).json({ ok: false, error: 'User not found' });
  }

  wallet.lastActive = new Date().toISOString();
  saveUserWallets();

  const userClean = normalizeEthiopianPhone(wallet.phone);
  const userTickets = userClean ? syncedTickets.filter(t => t.userPhone && normalizeEthiopianPhone(t.userPhone).endsWith(userClean.slice(-9))) : [];

  res.json({
    ok: true,
    user: {
      userId: wallet.userId,
      telegramId: wallet.telegramId || '',
      customerId: wallet.customerId || ('TEWEDAJ-' + (wallet.telegramId || wallet.userId || wallet.phone).slice(-6)),
      phone: userClean || wallet.phone || '',
      fullName: wallet.fullName || 'ተጠቃሚ',
      username: wallet.username || '',
      profileImage: wallet.profileImage || '',
      walletBalance: wallet.walletBalance || 0,
      ticketsCount: userTickets.length || wallet.ticketsCount || 0,
      totalWon: wallet.totalWon || 0,
      language: wallet.language || 'am',
      registeredAt: wallet.registeredAt,
      isAdmin: wallet.isAdmin || Boolean(userClean.includes('910961881')),
    },
  });
});

app.post('/api/user/wallet/update', (req, res) => {
  const { userId, phone, telegramId, walletBalance, ticketsCount, totalWon, fullName, username, profileImage } = req.body;
  if (!userId && !phone && !telegramId) {
    return res.status(400).json({ ok: false, error: 'User identifier required' });
  }

  const wallet = findOrCreateWallet({ userId, phone, telegramId, fullName, username, profileImage });
  if (typeof walletBalance === 'number') wallet.walletBalance = walletBalance;
  if (typeof ticketsCount === 'number') wallet.ticketsCount = ticketsCount;
  if (typeof totalWon === 'number') wallet.totalWon = totalWon;
  if (fullName && fullName.trim() && fullName !== 'ተጠቃሚ') wallet.fullName = fullName.trim();
  if (phone) wallet.phone = normalizeEthiopianPhone(phone);
  if (username) wallet.username = username;
  if (profileImage) wallet.profileImage = profileImage;
  if (telegramId) wallet.telegramId = String(telegramId);
  saveUserWallets();

  res.json({ ok: true, wallet });
});

app.post('/api/transactions/delete-batch', (req, res) => {
  const { transactionIds } = req.body;
  if (!Array.isArray(transactionIds) || transactionIds.length === 0) {
    return res.status(400).json({ ok: false, error: 'No transaction IDs provided' });
  }

  const idsSet = new Set(transactionIds);
  syncedTransactions = syncedTransactions.filter(t => !idsSet.has(t.id));
  saveTransactions();

  res.json({ ok: true, deletedCount: transactionIds.length, remaining: syncedTransactions.length });
});

// Admin endpoints for Group Chat Management
app.post('/api/admin/group/permissions', async (req, res) => {
  const { chatId, canSendMedia, adminPhone, adminUsername } = req.body;
  
  // Verify Admin
  const cleanPhone = adminPhone ? String(adminPhone).replace(/\D/g, '') : '';
  const isOwner = cleanPhone.includes('910961881') || (adminUsername && String(adminUsername).toLowerCase().includes('lij_makbel'));
  if (!isOwner) return res.status(403).json({ ok: false, error: 'Unauthorized' });

  try {
    const permissions = {
      can_send_messages: true,
      can_send_media_messages: canSendMedia, // Allow/Restrict images/videos
      can_send_polls: false,
      can_send_other_messages: false,
      can_add_web_page_previews: false,
      can_change_info: false,
      can_invite_users: false,
      can_pin_messages: false,
    };

    const tgRes = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setChatPermissions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, permissions }),
    });
    const data = await tgRes.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});


app.post('/api/transactions/:id/status', (req, res) => {
  const { id } = req.params;
  const { status, approvedBy } = req.body;
  const tx = syncedTransactions.find((t) => t.id === id);
  if (!tx) {
    return res.status(404).json({ ok: false, error: 'Transaction not found' });
  }

  const previousStatus = tx.status;
  tx.status = status;
  tx.approvedBy = approvedBy || 'Admin 0910961881';
  tx.approvedAt = new Date().toISOString();
  saveTransactions();

  const userWallet = findOrCreateWallet({ userId: tx.userId, phone: tx.userPhone, fullName: tx.userName });
  if (tx.type === 'deposit') {
    if (status === 'completed' && previousStatus !== 'completed') {
      userWallet.walletBalance += Number(tx.amount);
    }
  } else if (tx.type === 'withdrawal') {
    if (status === 'failed' && previousStatus !== 'failed') {
      userWallet.walletBalance += Number(tx.amount);
    }
  }
  saveUserWallets();

  const customerChatId = Number(tx.userId);
  if (!isNaN(customerChatId) && customerChatId > 0) {
    const userNotif = status === 'completed'
      ? (tx.type === 'deposit'
          ? `🎉 <b>የገንዘብ ማስገቢያ ጥያቄዎ በአድሚን ጸድቋል!</b>\n\nየ ${tx.amount.toLocaleString()} ብር ተቀብለን ወደ ዋሌትዎ ገብቷል:: አሁን ያለዎት ቀሪ ሒሳብ: <b>${userWallet.walletBalance.toLocaleString()} ብር</b>`
          : `💸 <b>የገንዘብ ማውጣት ጥያቄዎ በአድሚን ጸድቋል!</b>\n\nየ ${tx.amount.toLocaleString()} ብር ወደ አካውንትዎ (<code>${tx.userPhone}</code>) ተላልፏል::`)
      : (tx.type === 'deposit'
          ? `❌ የ ${tx.amount.toLocaleString()} ብር ገቢ ጥያቄዎ ውድቅ ተደርጓል:: ለተጨማሪ መረጃ ድጋፍ ሰጪውን ያነጋግሩ (@lij_makbel)`
          : `❌ የ ${tx.amount.toLocaleString()} ብር ማውጣት ጥያቄዎ ውድቅ ተደርጓል፤ ገንዘቡ ወደ ዋሌትዎ ተመልሷል::`);
    
    if (!userWallet.notifications) userWallet.notifications = [];
    userWallet.notifications.push({
      id: 'notif_' + Date.now(),
      message: userNotif,
      timestamp: new Date().toISOString(),
      isRead: false
    });
    saveUserWallets();
    sendTelegramResponse(customerChatId, userNotif);
  }

  res.json({ ok: true, transaction: tx });
});

app.get('/api/support/messages', (req, res) => {
  const userPhone = req.query.phone as string;
  if (!userPhone) {
    return res.json({ ok: true, messages: supportMessages.slice(-50) });
  }
  const cleanPhone = userPhone.replace(/\s+/g, '');
  const userFiltered = supportMessages.filter(
    (m) => m.userPhone.replace(/\s+/g, '').includes(cleanPhone) || cleanPhone.includes(m.userPhone.replace(/\s+/g, ''))
  );
  res.json({ ok: true, messages: userFiltered });
});

app.post('/api/support/send', async (req, res) => {
  const { userName, userPhone, text, userId } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ ok: false, error: 'Message text is required' });
  }

  const newMsg: SupportMessage = {
    id: 'sup_' + Date.now(),
    userId: userId || 'user',
    userName: (userName && userName !== 'ተጠቃሚ') ? userName : (userPhone || 'ደንበኛ'),
    userPhone: userPhone || '',
    sender: 'user',
    text: text.trim(),
    timestamp: new Date().toISOString(),
  };

  supportMessages.push(newMsg);
  saveSupportMessages();

  const adminNotification = 
    `💬 <b>አዲስ የድጋፍ መልዕክት (Support Inquiry)</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `👤 <b>ስም:</b> <b>${newMsg.userName}</b>\n` +
    `📱 <b>ስልክ:</b> <code>${newMsg.userPhone}</code>\n` +
    `📝 <b>መልዕክት:</b>\n` +
    `<i>"${newMsg.text}"</i>\n` +
    `━━━━━━━━━━━━━━━━━━━━`;

  await notifyAllAdmins(adminNotification);
  res.json({ ok: true, message: newMsg });
});

app.get('/api/group/chat/messages', (_req, res) => {
  res.json({ ok: true, messages: groupChatMessages.slice(-100) });
});

app.post('/api/group/chat/send', async (req, res) => {
  const { senderName, senderPhone, text, isAdmin, replyTo } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ ok: false, error: 'Text is required' });
  }

  const cleanPhone = senderPhone ? String(senderPhone).replace(/\D/g, '') : '';
  const verifiedAdmin = Boolean(isAdmin) || cleanPhone.includes('910961881');

  const newChatMsg: GroupChatMessage = {
    id: 'gc_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    senderName: (senderName && senderName !== 'ተጠቃሚ') ? senderName.trim() : (senderPhone || 'ደንበኛ'),
    senderPhone: senderPhone || '0910961881',
    text: text.trim(),
    timestamp: new Date().toISOString(),
    isAdmin: verifiedAdmin,
    replyTo: (replyTo && replyTo.text) ? {
      id: String(replyTo.id || ''),
      senderName: String(replyTo.senderName || ''),
      text: String(replyTo.text || ''),
    } : undefined,
  };

  groupChatMessages.push(newChatMsg);
  saveGroupChatMessages();

  if (!verifiedAdmin) {
    const adminAlertText = 
      `💬 <b>አዲስ መልዕክት በግሩፕ ቻት (Community Chat)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>ስም:</b> <b>${escapeHtml(newChatMsg.senderName)}</b>\n` +
      `📱 <b>ስልክ:</b> <code>${escapeHtml(newChatMsg.senderPhone)}</code>\n` +
      (newChatMsg.replyTo ? `↩️ <i>ምላሽ ለ (${escapeHtml(newChatMsg.replyTo.senderName)}): "${escapeHtml(newChatMsg.replyTo.text)}"\n</i>` : '') +
      `📝 <b>መልዕክት:</b>\n` +
      `<i>"${escapeHtml(newChatMsg.text)}"</i>\n` +
      `━━━━━━━━━━━━━━━━━━━━`;
    await notifyAllAdmins(adminAlertText);
  }

  res.json({ ok: true, message: newChatMsg, messages: groupChatMessages.slice(-100) });
});

app.post('/api/group/chat/delete', (req, res) => {
  const { messageId, adminPhone, adminUsername } = req.body;
  const cleanPhone = adminPhone ? String(adminPhone).replace(/\D/g, '') : '';
  const isOwner = cleanPhone.includes('910961881') || (adminUsername && String(adminUsername).toLowerCase().includes('lij_makbel'));

  if (!isOwner) {
    return res.status(403).json({ ok: false, error: 'Unauthorized. Only owner can delete messages.' });
  }

  groupChatMessages = groupChatMessages.filter(m => m.id !== messageId);
  saveGroupChatMessages();

  res.json({ ok: true, messages: groupChatMessages.slice(-100) });
});

app.post('/api/telegram/webhook', async (req, res) => {
  res.sendStatus(200);
  if (req.body?.message) {
    await handleTelegramMessage(req.body.message);
  } else if (req.body?.callback_query) {
    await handleTelegramCallback(req.body.callback_query);
  }
});

const UPDATE_ID_FILE = path.join(__dirname, 'last_update_id.txt');
let lastUpdateId = 0;

try {
  if (fs.existsSync(UPDATE_ID_FILE)) {
    lastUpdateId = parseInt(fs.readFileSync(UPDATE_ID_FILE, 'utf-8').trim(), 10) || 0;
  }
} catch {
  lastUpdateId = 0;
}

function saveLastUpdateId(id: number) {
  try {
    fs.writeFileSync(UPDATE_ID_FILE, String(id));
  } catch {}
}

async function startTelegramPolling() {
  console.log(`[Telegram Bot] Starting polling for @${BOT_USERNAME}...`);
  try {
    await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setMyCommands`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        commands: [
          { command: 'start', description: 'ቦቱን ጀምር / Start Bot' },
        ],
      }),
    });

    await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setChatMenuButton`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        menu_button: {
          type: 'web_app',
          text: 'OPEN',
          web_app: { url: APP_URL },
        },
      }),
    });
  } catch (err) {
    console.error('[Bot Init Warning]', err);
  }

  while (true) {
    try {
      const offset = lastUpdateId > 0 ? lastUpdateId + 1 : 0;
      const res = await fetch(
        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getUpdates?offset=${offset}&timeout=20`
      );
      if (!res.ok) {
        await new Promise((resolve) => setTimeout(resolve, 3000));
        continue;
      }
      const data = (await res.json()) as any;
      if (data && data.ok && Array.isArray(data.result)) {
        for (const update of data.result) {
          lastUpdateId = update.update_id;
          saveLastUpdateId(lastUpdateId);
          try {
            if (update.message) {
              await handleTelegramMessage(update.message);
            } else if (update.callback_query) {
              await handleTelegramCallback(update.callback_query);
            }
          } catch (innerErr) {
            console.error('[Update Processing Error]', update.update_id, innerErr);
          }
        }
      }
    } catch {
      // transient network wait
    }
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
}

async function startServer() {
  const distPath = path.join(__dirname, 'dist');
  const hasDist = fs.existsSync(distPath);
  const isDev = process.env.NODE_ENV !== 'production' && !hasDist;

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, async () => {
    console.log(`[Tewedaj Server] Running on http://0.0.0.0:${PORT}`);
    await loadAllFromFirestore();
    startTelegramPolling().catch((err) => console.error('[Polling Fatal Error]', err));
  });
}

startServer();
