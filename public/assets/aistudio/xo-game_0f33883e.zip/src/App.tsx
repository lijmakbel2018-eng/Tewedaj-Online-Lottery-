/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  RotateCcw,
  Volume2,
  VolumeX,
  Award,
  Wallet,
  Coins,
  Plus,
  Search,
  UserCheck,
  X as CloseIcon,
} from 'lucide-react';
import {
  type CellValue,
  type Player,
  type AIDifficulty,
  type WinResult,
  type MoveRecord,
  checkWin,
  isBoardFull,
  getAIMove,
} from './utils/gameLogic';
import { sound } from './utils/audio';
import { DoodleGrid } from './components/DoodleGrid';

const BET_AMOUNTS = [10, 20, 30, 50, 100, 150, 200];
const OPPONENT_NAMES = ['ዮናስ', 'አቤል', 'ሳራ', 'ኤልያስ', 'ኪሩቤል', 'አስቴር', 'ሄኖክ', 'ቢኒያም', 'ሩት', 'ዳዊት'];

export default function App() {
  const [isMuted, setIsMuted] = useState<boolean>(() => sound.getMuted());
  const difficulty: AIDifficulty = 'medium';

  // Wallet & Betting State
  const [wallet, setWallet] = useState<number>(() => {
    const saved = localStorage.getItem('neon_xo_wallet');
    return saved !== null ? Math.max(0, Number(saved)) : 500;
  });
  const [currentBet, setCurrentBet] = useState<number>(20);
  const [lastOutcome, setLastOutcome] = useState<{
    type: 'win' | 'lose' | 'draw' | null;
    amount: number;
    cut: number;
  }>({ type: null, amount: 0, cut: 0 });

  // Matchmaking State (Find Player)
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [opponent, setOpponent] = useState<string>('ተጋጣሚ (Opponent)');

  // Active Game State
  const [board, setBoard] = useState<CellValue[]>(() => Array(9).fill(null));
  const [turn, setTurn] = useState<Player>('X');
  const [winnerInfo, setWinnerInfo] = useState<WinResult | null>(null);
  const [isDraw, setIsDraw] = useState<boolean>(false);
  const [moveHistory, setMoveHistory] = useState<MoveRecord[]>([]);

  // Persist wallet
  useEffect(() => {
    localStorage.setItem('neon_xo_wallet', wallet.toString());
  }, [wallet]);

  // Start / Reset Game
  const startNewGame = useCallback(() => {
    setBoard(Array(9).fill(null));
    setTurn('X');
    setWinnerInfo(null);
    setIsDraw(false);
    setMoveHistory([]);
    setLastOutcome({ type: null, amount: 0, cut: 0 });
    sound.playUndo();
  }, []);

  // Find Player Matchmaking Function
  const handleFindPlayer = () => {
    if (wallet < currentBet) {
      sound.playCoinLose();
      return;
    }
    setIsSearching(true);
    sound.playTap();

    // Realistic matchmaking search: searches for a player with matching bet stake
    const randomOpponent = OPPONENT_NAMES[Math.floor(Math.random() * OPPONENT_NAMES.length)];
    setTimeout(() => {
      setOpponent(randomOpponent);
      setIsSearching(false);
      startNewGame();
      sound.playCoinWin();
    }, 1400);
  };

  // Top-up wallet if low
  const handleTopUp = () => {
    setWallet((prev) => prev + 100);
    sound.playCoinWin();
  };

  // Execute Move
  const handleCellClick = useCallback(
    (index: number) => {
      if (board[index] !== null || winnerInfo || isDraw) {
        return;
      }

      const nextBoard = [...board];
      nextBoard[index] = turn;
      sound.playNeonLaser(turn);

      const newHistory: MoveRecord[] = [
        ...moveHistory,
        {
          step: moveHistory.length + 1,
          cellIndex: index,
          player: turn,
          boardSnapshot: [...nextBoard],
        },
      ];
      setMoveHistory(newHistory);
      setBoard(nextBoard);

      // Check for win
      const win = checkWin(nextBoard, 3);
      if (win) {
        setWinnerInfo(win);
        sound.playWin();

        if (win.winner === 'X') {
          // Player Wins: 20% cut deducted from winner's earnings! Net profit is 80% of bet!
          const cut = Math.round(currentBet * 0.20);
          const netWin = currentBet - cut;
          setWallet((prev) => prev + netWin);
          setLastOutcome({ type: 'win', amount: netWin, cut });
          sound.playCoinWin();
        } else {
          // Opponent Wins: Deduct full bet amount!
          setWallet((prev) => Math.max(0, prev - currentBet));
          setLastOutcome({ type: 'lose', amount: currentBet, cut: 0 });
          sound.playCoinLose();
        }

        confetti({
          particleCount: 75,
          spread: 80,
          origin: { y: 0.55 },
          colors: win.winner === 'X' ? ['#ff1744', '#ff5252', '#ffffff', '#ffd700'] : ['#00e5ff', '#0070f3', '#ffffff'],
        });
        return;
      }

      // Check for draw: NO DEDUCTION! (0 Birr cut, 100% money is safe!)
      if (isBoardFull(nextBoard)) {
        setIsDraw(true);
        setLastOutcome({ type: 'draw', amount: 0, cut: 0 });
        sound.playDraw();
        return;
      }

      // Switch turn
      setTurn(turn === 'X' ? 'O' : 'X');
    },
    [board, winnerInfo, isDraw, turn, moveHistory, currentBet]
  );

  // Lightning-fast Opponent response (~70ms) - feels like an agile human opponent reacting instantly
  useEffect(() => {
    if (turn !== 'O' || winnerInfo || isDraw) {
      return;
    }

    const timer = setTimeout(() => {
      const aiMoveIndex = getAIMove(board, difficulty, 3);
      if (aiMoveIndex !== -1) {
        handleCellClick(aiMoveIndex);
      }
    }, 70);

    return () => clearTimeout(timer);
  }, [turn, winnerInfo, isDraw, board, difficulty, handleCellClick]);

  const isGameActive = moveHistory.length > 0 && !winnerInfo && !isDraw;

  return (
    <div
      className="min-h-screen flex flex-col justify-between font-sans text-white select-none relative"
      style={{
        background: 'radial-gradient(circle at 50% 35%, #18113c 0%, #0c0822 65%, #050311 100%)',
      }}
    >
      {/* Top Header - "XO GAME" + WALLET + FIND PLAYER + Quick Icons */}
      <header className="flex items-center justify-between px-3 sm:px-6 py-3 border-b border-indigo-900/40 bg-black/30 backdrop-blur-md">
        {/* Title + Wallet Badge */}
        <div className="flex items-center gap-2 sm:gap-4">
          <h1
            className="text-xl sm:text-3xl font-black tracking-widest text-white shrink-0"
            style={{
              textShadow: '0 0 12px rgba(0, 229, 255, 0.7), 0 0 25px rgba(255, 23, 68, 0.5)',
            }}
          >
            XO GAME
          </h1>

          {/* Wallet Display */}
          <div className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-xl bg-gradient-to-r from-amber-500/20 to-amber-600/10 border border-amber-500/50 shadow-[0_0_12px_rgba(245,158,11,0.25)]">
            <Wallet className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-amber-400" />
            <span className="hidden xs:inline text-[10px] sm:text-[11px] font-semibold text-amber-400/80 uppercase">
              Wallet:
            </span>
            <span className="font-mono text-xs sm:text-base font-black tabular-nums text-amber-300">
              {wallet.toLocaleString()}
            </span>
            <span className="text-[10px] sm:text-xs font-bold text-amber-400">ብር</span>

            {/* Quick deposit button if running low */}
            {wallet < currentBet && (
              <button
                type="button"
                onClick={handleTopUp}
                className="ml-1 flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-amber-500 hover:bg-amber-400 text-slate-950 text-[10px] font-extrabold cursor-pointer transition-colors shadow-xs"
                title="100 ብር ጨምር (Add 100 Birr)"
              >
                <Plus className="w-3 h-3" />
                <span>100</span>
              </button>
            )}
          </div>
        </div>

        {/* Minimal Controls + Find Player */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Find Player Button (Replaces P2) */}
          <button
            type="button"
            disabled={isSearching}
            onClick={handleFindPlayer}
            className="px-2.5 sm:px-3 py-1.5 rounded-lg border border-cyan-500/60 bg-gradient-to-r from-cyan-500/20 to-blue-600/30 hover:from-cyan-500/30 hover:to-blue-600/40 text-cyan-300 hover:text-white transition-all cursor-pointer flex items-center gap-1.5 font-bold text-xs shadow-[0_0_10px_rgba(0,229,255,0.3)] active:scale-95"
            title="በተመረጠው የብር መጠን ተጋጣሚ ፈልግ"
          >
            <Search className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span className="whitespace-nowrap">Find Player</span>
          </button>

          {/* Sound Toggle */}
          <button
            type="button"
            onClick={() => setIsMuted(sound.toggleMute())}
            className="p-1.5 sm:p-2 rounded-lg border border-indigo-900/80 bg-[#140f33] text-slate-300 hover:text-white cursor-pointer transition-colors"
            title={isMuted ? 'Muted' : 'Sound On'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-stone-500" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>

          {/* Restart */}
          <button
            type="button"
            onClick={() => startNewGame()}
            className="p-1.5 sm:p-2 rounded-lg border border-indigo-900/80 bg-[#140f33] text-slate-300 hover:text-white cursor-pointer transition-colors"
            title="Restart"
          >
            <RotateCcw className="w-4 h-4 text-rose-400" />
          </button>
        </div>
      </header>

      {/* Main Game Screen */}
      <main className="flex-1 w-full max-w-md mx-auto px-4 flex flex-col items-center justify-center py-2">
        {/* Status & Outcome Announcement */}
        <div className="mb-2 text-center min-h-[36px] flex items-center justify-center">
          {winnerInfo ? (
            <div
              className="flex items-center gap-2 text-base sm:text-lg font-black animate-pulse"
              style={{
                color: winnerInfo.winner === 'X' ? '#4ade80' : '#ff3366',
                textShadow: winnerInfo.winner === 'X' ? '0 0 16px #22c55e' : '0 0 16px #ff1744',
              }}
            >
              <Award className="w-5 h-5" />
              <span>
                {winnerInfo.winner === 'X'
                  ? `አሸነፉ! +${lastOutcome.amount} ብር (20% ተቆርጦ) 💰`
                  : `ተሸነፉ! -${lastOutcome.amount} ብር`}
              </span>
            </div>
          ) : isDraw ? (
            <div className="text-sm sm:text-base font-bold text-amber-300 flex items-center gap-1.5">
              <span>አቻ ወጣ! ምንም አልተቆረጠም (0 ብር) 🤝</span>
            </div>
          ) : (
            <div className="flex items-center gap-3 text-sm font-bold tracking-wide">
              <span
                style={{
                  color: turn === 'X' ? '#ff4070' : '#00e5ff',
                  textShadow: turn === 'X' ? '0 0 10px #ff1744' : '0 0 10px #00e5ff',
                }}
              >
                ተራ፡ {turn === 'X' ? 'እርስዎ (X)' : `${opponent} (O)`}
              </span>
              <span className="text-xs opacity-60">·</span>
              <span className="text-xs font-mono font-semibold text-amber-300/90">
                ውርርድ፡ {currentBet} ብር
              </span>
            </div>
          )}
        </div>

        {/* 3D Glowing Neon 3x3 Grid */}
        <div className="w-full flex justify-center">
          <DoodleGrid
            board={board}
            size={3}
            turn={turn}
            winnerInfo={winnerInfo}
            onCellClick={handleCellClick}
            disabled={Boolean(winnerInfo || isDraw || isSearching)}
            theme="neon"
          />
        </div>

        {/* Action Controls: Selected Bet Display (No 'የመወዳደሪያ' text) & Play Again */}
        <div className="w-full max-w-xs mx-auto flex items-center justify-center gap-3 mt-3">
          {/* Active Bet Badge (Selected from bottom) */}
          <div className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-amber-500/60 bg-[#140f33] text-xs font-bold shadow-[0_0_12px_rgba(245,158,11,0.25)]">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="font-mono text-sm font-black text-amber-300 tabular-nums">
              {currentBet} ብር
            </span>
          </div>

          <button
            type="button"
            onClick={() => startNewGame()}
            className="px-5 py-2 text-xs font-bold rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 hover:shadow-[0_0_15px_rgba(0,229,255,0.5)] active:scale-98 transition-all cursor-pointer flex items-center gap-1.5 shadow-md"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>አዲስ ጨዋታ</span>
          </button>
        </div>
      </main>

      {/* Bottom Area: Betting Amount Selector (10, 20, 30, 50, 100, 150, 200 Birr) */}
      <footer className="w-full max-w-md mx-auto px-4 py-3 bg-black/50 backdrop-blur-md border-t border-indigo-900/50 rounded-t-2xl">
        <div className="flex items-center justify-between mb-2 px-1">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
            <Coins className="w-4 h-4 text-amber-400" />
            <span>የመጫወቻ የብር መጠን (Stake):</span>
          </div>
          <span className="text-xs font-mono font-extrabold text-amber-400">
            {currentBet} ብር
          </span>
        </div>

        {/* 7 Stake Buttons: 10, 20, 30, 50, 100, 150, 200 Birr */}
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5">
          {BET_AMOUNTS.map((amt) => {
            const isSelected = currentBet === amt;
            const isAffordable = wallet >= amt;

            return (
              <button
                key={amt}
                type="button"
                disabled={isGameActive || !isAffordable}
                onClick={() => {
                  setCurrentBet(amt);
                  sound.playTap();
                }}
                className={`py-1.5 px-1 rounded-lg text-xs font-bold transition-all text-center cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black shadow-[0_0_12px_rgba(0,229,255,0.6)] scale-105'
                    : isAffordable
                    ? 'bg-[#140f33] hover:bg-[#1f174d] text-slate-200 border border-indigo-900/80'
                    : 'bg-black/30 text-stone-600 border border-stone-800/40 opacity-40 cursor-not-allowed'
                }`}
                title={`${amt} ብር`}
              >
                {amt} ብር
              </button>
            );
          })}
        </div>
      </footer>

      {/* Find Player Matchmaking Modal Overlay */}
      {isSearching && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-sm rounded-2xl p-6 bg-[#130f2e] border border-cyan-500/60 shadow-[0_0_35px_rgba(0,229,255,0.3)] text-center flex flex-col items-center">
            {/* Animated Radar Pulse */}
            <div className="relative w-20 h-20 mb-4 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-2 border-cyan-400/30 animate-ping" />
              <div className="absolute inset-2 rounded-full border-2 border-cyan-400/50 animate-pulse" />
              <div className="relative w-12 h-12 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center">
                <Search className="w-6 h-6 text-cyan-300 animate-spin" style={{ animationDuration: '3s' }} />
              </div>
            </div>

            <h3 className="text-lg font-black text-white mb-1">
              ተጋጣሚ በመፈለግ ላይ...
            </h3>
            <p className="text-xs text-slate-300 mb-3">
              በ <span className="text-amber-300 font-bold font-mono">{currentBet} ብር</span> የሚጫወት ተጋጣሚ በማፈላለግ ላይ...
            </p>

            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/40 border border-indigo-900/60 text-xs text-cyan-400 font-semibold mb-4">
              <UserCheck className="w-4 h-4 text-cyan-400" />
              <span>ተጋጣሚዎች በመገናኘት ላይ</span>
            </div>

            <button
              type="button"
              onClick={() => setIsSearching(false)}
              className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer font-bold"
            >
              <CloseIcon className="w-3.5 h-3.5" />
              <span>አቋርጥ (Cancel)</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
