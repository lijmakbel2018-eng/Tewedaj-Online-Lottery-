import React, { useState } from 'react';
import { 
  Wallet, 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Copy, 
  Check, 
  Search, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Ticket as TicketIcon,
  Sparkles,
  TrendingUp,
  TrendingDown,
  Trash2,
  CheckSquare,
  Square,
} from 'lucide-react';
import { Language, Transaction, UserProfile, Ticket } from '../../types/lottery';
import { TelebirrLogo } from '../common/TelebirrLogo';
import { copyTextToClipboard } from '../../utils/lotteryUtils';

interface WalletViewProps {
  user: UserProfile;
  transactions: Transaction[];
  tickets?: Ticket[];
  lang: Language;
  onOpenDeposit: () => void;
  onOpenWithdraw: () => void;
  onDeleteTransactions?: (txIds: string[]) => void;
  triggerHaptic?: (style: 'light' | 'medium' | 'heavy') => void;
  playNotificationSound?: (type: 'click' | 'win' | 'alert') => void;
}

export const WalletView: React.FC<WalletViewProps> = ({
  user,
  transactions,
  tickets = [],
  lang,
  onOpenDeposit,
  onOpenWithdraw,
  onDeleteTransactions,
  triggerHaptic,
  playNotificationSound,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'deposit' | 'withdrawal' | 'ticket_purchase'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [selectedTxIds, setSelectedTxIds] = useState<Set<string>>(new Set());

  const toggleSelectTx = (id: string) => {
    triggerHaptic?.('light');
    setSelectedTxIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleSelectAll = () => {
    triggerHaptic?.('light');
    // Compute current filtered list
    const currentFiltered = myTransactions.filter(t => {
      if (filterType !== 'all' && t.type !== filterType) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        return t.referenceNumber?.toLowerCase().includes(q) || 
               String(t.amount).includes(q) || 
               t.lotteryTitleAm?.toLowerCase().includes(q) || 
               t.userPhone?.includes(q);
      }
      return true;
    });

    if (selectedTxIds.size === currentFiltered.length && currentFiltered.length > 0) {
      setSelectedTxIds(new Set());
    } else {
      setSelectedTxIds(new Set(currentFiltered.map(t => t.id)));
    }
  };

  const handleDeleteSelected = () => {
    console.log('Delete selected clicked, IDs:', Array.from(selectedTxIds));
    if (selectedTxIds.size === 0) return;
    const count = selectedTxIds.size;
    if (!window.confirm(lang === 'am' ? `የተመረጡትን ${count} ዝውውሮች መሰረዝ ይፈልጋሉ?` : `Delete selected ${count} transactions?`)) {
      return;
    }
    triggerHaptic?.('medium');
    playNotificationSound?.('alert');
    onDeleteTransactions?.(Array.from(selectedTxIds));
    setSelectedTxIds(new Set());
    setIsSelectMode(false);
  };

  const handleCopy = (text: string, keyId: string) => {
    if (!text) return;
    copyTextToClipboard(text);
    setCopiedKey(keyId);
    triggerHaptic?.('light');
    playNotificationSound?.('click');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const cleanPhone = user.phone ? user.phone.replace(/\D/g, '') : '';
  const myTransactions = transactions.filter(t => {
    if (!cleanPhone) return false;
    return Boolean(t.userPhone && t.userPhone.replace(/\D/g, '').endsWith(cleanPhone.slice(-9)));
  });

  const totalDeposits = myTransactions
    .filter(t => t.type === 'deposit' && t.status === 'completed')
    .reduce((acc, t) => acc + (t.amount || 0), 0);

  const totalWithdrawals = myTransactions
    .filter(t => t.type === 'withdrawal' && t.status === 'completed')
    .reduce((acc, t) => acc + (t.amount || 0), 0);

  const totalTicketSpend = myTransactions
    .filter(t => t.type === 'ticket_purchase' && t.status === 'completed')
    .reduce((acc, t) => acc + (t.amount || 0), 0);

  const filteredTransactions = myTransactions.filter(t => {
    if (filterType !== 'all' && t.type !== filterType) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      const matchRef = t.referenceNumber?.toLowerCase().includes(q);
      const matchAmount = String(t.amount).includes(q);
      const matchTitle = t.lotteryTitleAm?.toLowerCase().includes(q);
      const matchPhone = t.userPhone?.includes(q);
      return matchRef || matchAmount || matchTitle || matchPhone;
    }
    return true;
  });

  const cleanUserPhone = (user.phone || '').replace(/\D/g, '');
  const myTickets = (tickets || []).filter(t => {
    if (cleanUserPhone && t.userPhone) {
      const tPhone = t.userPhone.replace(/\D/g, '');
      if (tPhone && !tPhone.endsWith(cleanUserPhone.slice(-9)) && !cleanUserPhone.endsWith(tPhone.slice(-9))) {
        return false;
      }
    }
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      const matchNum = t.ticketNumber?.includes(q);
      const matchTitle = t.lotteryTitleAm?.toLowerCase().includes(q) || t.lotteryTitleEn?.toLowerCase().includes(q);
      const matchRef = t.paymentReference?.toLowerCase().includes(q);
      return matchNum || matchTitle || matchRef;
    }
    return true;
  });

  return (
    <div className="space-y-4 sm:space-y-5 animate-in fade-in duration-300">
      {/* Balance Hero Card */}
      <div className="bg-gradient-to-br from-slate-900 via-emerald-950/40 to-slate-950 border border-emerald-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl relative overflow-hidden space-y-5">
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
              {lang === 'am' ? 'ያለዎት ቀሪ ሒሳብ' : 'Available Balance'}
            </span>
            <div className="text-3xl sm:text-4xl font-black text-emerald-400 font-sans tabular-nums mt-1.5 flex items-baseline gap-2">
              <span>{user.walletBalance.toLocaleString()}</span>
              <span className="text-lg sm:text-xl text-emerald-300 font-sans font-bold">ብር (ETB)</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2.5 sm:w-auto shrink-0">
            <button
              type="button"
              onClick={() => {
                onOpenDeposit();
                triggerHaptic?.('medium');
                playNotificationSound?.('click');
              }}
              className="py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50 transition active:scale-95"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>{lang === 'am' ? 'ገንዘብ አስገባ' : 'Deposit'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onOpenWithdraw();
                triggerHaptic?.('medium');
                playNotificationSound?.('click');
              }}
              className="py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-950/50 transition active:scale-95"
            >
              <ArrowUpRight className="w-4 h-4 stroke-[3]" />
              <span>{lang === 'am' ? 'ገንዘብ አውጣ' : 'Withdraw'}</span>
            </button>
          </div>
        </div>

        {/* Mini stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-4 border-t border-slate-800/80">
          <div className="bg-slate-950/80 p-3 rounded-2xl border border-emerald-500/20">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-slate-400 font-semibold">{lang === 'am' ? 'ጠቅላላ ገቢ' : 'Total Deposits'}</span>
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-sm font-black text-emerald-400 font-sans tabular-nums mt-1">
              +{totalDeposits.toLocaleString()} ብር
            </div>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-2xl border border-amber-500/20">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-slate-400 font-semibold">{lang === 'am' ? 'ጠቅላላ ወጪ' : 'Total Withdrawals'}</span>
              <TrendingDown className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="text-sm font-black text-amber-400 font-sans tabular-nums mt-1">
              -{totalWithdrawals.toLocaleString()} ብር
            </div>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-slate-400 font-semibold">{lang === 'am' ? 'ለትኬት የወጣ' : 'Ticket Spend'}</span>
              <TicketIcon className="w-3.5 h-3.5 text-teal-400" />
            </div>
            <div className="text-sm font-black text-teal-300 font-sans tabular-nums mt-1">
              {totalTicketSpend.toLocaleString()} ብር
            </div>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-2xl border border-amber-500/20">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-slate-400 font-semibold">{lang === 'am' ? 'ያሸነፉት ጠቅላላ' : 'Total Won'}</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="text-sm font-black text-amber-400 font-sans tabular-nums mt-1">
              {user.totalWon.toLocaleString()} ብር
            </div>
          </div>
        </div>
      </div>





      {/* Transactions History */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl space-y-4">
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <span>{lang === 'am' ? 'ዝርዝሮች' : 'Details'}</span>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                  {filteredTransactions.length}
                </span>
              </h3>
            </div>

            <div className="relative min-w-[200px]">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder=""
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {[
              { id: 'all', label: lang === 'am' ? 'ሁሉም' : 'All' },
              { id: 'deposit', label: lang === 'am' ? 'ገቢዎች' : 'Deposits' },
              { id: 'withdrawal', label: lang === 'am' ? 'ወጪዎች' : 'Withdrawals' },
              { id: 'ticket_purchase', label: lang === 'am' ? 'የእኔ ትኬቶች' : 'My Tickets' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setFilterType(tab.id as any);
                  triggerHaptic?.('light');
                }}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition active:scale-95 ${
                  filterType === tab.id
                    ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}

            {/* Delete icon button placed right beside 'የትኬት ግዢዎች' */}
            {myTransactions.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  triggerHaptic?.('light');
                  setIsSelectMode(prev => !prev);
                  setSelectedTxIds(new Set());
                }}
                className={`px-2.5 py-1.5 rounded-xl border font-bold transition active:scale-95 flex items-center gap-1.5 shrink-0 ${
                  isSelectMode
                    ? 'bg-rose-500 text-white border-rose-500 shadow-md shadow-rose-500/25'
                    : 'bg-slate-950 text-rose-400 border-rose-500/40 hover:bg-rose-950/40'
                }`}
                title={lang === 'am' ? 'ዝርዝር ሰርዝ' : 'Delete transactions'}
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="text-[11px] font-bold">
                  {isSelectMode ? (lang === 'am' ? 'ይቅር' : 'Cancel') : (lang === 'am' ? 'ሰርዝ' : 'Delete')}
                </span>
              </button>
            )}
          </div>

          {/* Select Mode Action Bar */}
          {isSelectMode && (
            <div className="bg-slate-900 border border-rose-500/30 rounded-2xl p-2.5 flex items-center justify-between gap-2 text-xs animate-in slide-in-from-top-1 mt-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSelectAll}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold text-[11px] flex items-center gap-1.5 transition active:scale-95"
                >
                  {selectedTxIds.size === filteredTransactions.length && filteredTransactions.length > 0 ? (
                    <CheckSquare className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Square className="w-3.5 h-3.5 text-slate-400" />
                  )}
                  <span>
                    {selectedTxIds.size === filteredTransactions.length && filteredTransactions.length > 0
                      ? (lang === 'am' ? 'ሁሉንም አውርድ' : 'Deselect All')
                      : (lang === 'am' ? 'ሁሉንም ምረጥ' : 'Select All')}
                  </span>
                </button>
                <span className="text-slate-400 text-[11px]">
                  {selectedTxIds.size} {lang === 'am' ? 'ተመርጧል' : 'selected'}
                </span>
              </div>

              <button
                type="button"
                disabled={selectedTxIds.size === 0}
                onClick={handleDeleteSelected}
                className="px-3 py-1 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-black rounded-xl text-[11px] flex items-center gap-1.5 shadow transition active:scale-95"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{lang === 'am' ? 'የተመረጡትን ሰርዝ' : 'Delete Selected'} ({selectedTxIds.size})</span>
              </button>
            </div>
          )}
        </div>

        {filterType === 'ticket_purchase' ? (
          myTickets.length === 0 ? (
            <div className="text-center py-10 px-4 bg-slate-950/60 rounded-2xl border border-slate-800/80 space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-amber-400">
                <TicketIcon className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-slate-300">
                {lang === 'am' ? 'ምንም የተቆረጠ ትኬት የለም' : 'No purchased tickets found'}
              </p>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                {lang === 'am' 
                  ? 'ትኬት ለመቁረጥ ወደ ዋናው የሎተሪ ገጽ በመሄድ ይምረጡ' 
                  : 'Select a lottery from the home screen to buy tickets'}
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>{lang === 'am' ? 'የእኔ ትኬቶች ዝርዝር' : 'My Tickets List'}</span>
                <span className="font-bold text-amber-400 font-mono">{myTickets.length} {lang === 'am' ? 'ትኬት' : 'tickets'}</span>
              </div>
              {myTickets.map((tkt) => {
                const isWon = tkt.status === 'won';
                const isLost = tkt.status === 'lost';

                return (
                  <div
                    key={tkt.id}
                    className="p-3.5 bg-gradient-to-br from-slate-900/95 via-slate-950 to-slate-900/90 rounded-2xl border border-slate-800 hover:border-amber-500/40 transition shadow-md flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                        isWon 
                          ? 'bg-amber-500/20 border-amber-500/40 text-amber-400' 
                          : 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                      }`}>
                        <TicketIcon className="w-5 h-5 stroke-[2.2]" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-base text-yellow-400 tracking-wider">
                            #{tkt.ticketNumber}
                          </span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              copyTextToClipboard(tkt.ticketNumber);
                              setCopiedKey(tkt.id);
                              triggerHaptic?.('light');
                              setTimeout(() => setCopiedKey(null), 1500);
                            }}
                            className="text-slate-500 hover:text-white p-0.5 rounded transition cursor-pointer"
                            title="Copy ticket number"
                          >
                            {copiedKey === tkt.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                        <div className="text-xs font-bold text-white truncate mt-0.5">
                          {tkt.lotteryTitleAm} {tkt.round ? `(ዙር ${tkt.round})` : ''}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                          {new Date(tkt.purchasedAt || Date.now()).toLocaleDateString('am-ET')} • {tkt.pricePaid} ብር
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0 space-y-1">
                      {isWon ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-black text-amber-400 bg-amber-500/15 px-2.5 py-1 rounded-lg border border-amber-500/30 shadow-sm animate-pulse">
                          🏆 {lang === 'am' ? 'አሸናፊ' : 'Winner'} (+{tkt.prizeWon?.toLocaleString()} ብር)
                        </span>
                      ) : isLost ? (
                        <span className="inline-flex items-center text-[10px] font-bold text-slate-500 bg-slate-900 px-2 py-0.5 rounded-md border border-slate-800">
                          {lang === 'am' ? 'ያላለፈ' : 'Ended'}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                          <span>{lang === 'am' ? 'በመጠባበቅ ላይ' : 'Active'}</span>
                        </span>
                      )}
                      <div className="text-[10px] text-slate-500 font-mono">
                        {tkt.paymentReference ? `REF: ${tkt.paymentReference.slice(0, 10)}` : 'VERIFIED'}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )
        ) : filteredTransactions.length === 0 ? (
          <div className="text-center py-10 px-4 bg-slate-950/60 rounded-2xl border border-slate-800/80 space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-500">
              <Clock className="w-6 h-6" />
            </div>
            <p className="text-sm font-bold text-slate-300">
              {lang === 'am' ? 'ምንም የገንዘብ ዝውውር አልተገኘም' : 'No transactions found'}
            </p>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              {lang === 'am' 
                ? 'ገንዘብ ለማስገባት ከላይ ያለውን "ገንዘብ አስገባ" የሚለውን ይጫኑ' 
                : 'Tap Deposit above to add funds to your wallet'}
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {filteredTransactions.map((tx) => {
              const isDeposit = tx.type === 'deposit';
              const isWithdrawal = tx.type === 'withdrawal';
              const isTicket = tx.type === 'ticket_purchase';
              const isCompleted = tx.status === 'completed';
              const isPending = tx.status === 'pending';
              const isFailed = tx.status === 'failed';
              const isSelected = selectedTxIds.has(tx.id);

              return (
                <div
                  key={tx.id}
                  onClick={() => {
                    if (isSelectMode) {
                      toggleSelectTx(tx.id);
                    }
                  }}
                  className={`p-3.5 bg-slate-950/90 rounded-2xl border transition flex items-center justify-between gap-3 text-xs ${
                    isSelectMode ? 'cursor-pointer hover:border-slate-600' : 'hover:border-slate-700'
                  } ${
                    isSelected ? 'border-rose-500 bg-rose-950/25 ring-1 ring-rose-500/50' : 'border-slate-800/90'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {isSelectMode && (
                      <div className="shrink-0 text-slate-400">
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-rose-400" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-500" />
                        )}
                      </div>
                    )}
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                      isDeposit 
                        ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400' 
                        : isWithdrawal
                        ? 'bg-amber-500/15 border-amber-500/30 text-amber-400'
                        : 'bg-teal-500/15 border-teal-500/30 text-teal-400'
                    }`}>
                      {isDeposit && <ArrowDownLeft className="w-4 h-4 stroke-[2.5]" />}
                      {isWithdrawal && <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />}
                      {isTicket && <TicketIcon className="w-4 h-4 stroke-[2]" />}
                    </div>
                    <div className="min-w-0">
                      <div className="font-black text-white truncate text-xs sm:text-sm">
                        {isDeposit && (lang === 'am' ? 'የዋሌት ገቢ' : 'Wallet Deposit')}
                        {isWithdrawal && (lang === 'am' ? 'የዋሌት ወጪ (Withdrawal)' : 'Wallet Withdrawal')}
                        {isTicket && (lang === 'am' ? (tx.lotteryTitleAm || 'የትኬት ግዢ') : 'Ticket Purchase')}
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mt-0.5">
                        <span className="truncate">
                          {tx.referenceNumber || 'TX-REF'}
                        </span>
                        {tx.referenceNumber && (
                          <button
                            type="button"
                            onClick={() => handleCopy(tx.referenceNumber, tx.id)}
                            className="text-slate-500 hover:text-white"
                            title="Copy reference"
                          >
                            {copiedKey === tx.id ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className={`font-mono font-black text-xs sm:text-sm ${
                      isDeposit 
                        ? 'text-emerald-400' 
                        : isWithdrawal 
                        ? 'text-amber-400' 
                        : 'text-slate-300'
                    }`}>
                      {isDeposit ? '+' : '-'}{tx.amount.toLocaleString()} ብር
                    </div>
                    <div className="mt-0.5">
                      {isCompleted && (
                        <span className="inline-flex items-center gap-1 text-[9px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          <span>{lang === 'am' ? 'ተጠናቋል' : 'Completed'}</span>
                        </span>
                      )}
                      {isPending && (
                        <span className="inline-flex items-center gap-1 text-[9px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                          <Clock className="w-2.5 h-2.5" />
                          <span>{lang === 'am' ? 'በመጠባበቅ ላይ' : 'Pending'}</span>
                        </span>
                      )}
                      {isFailed && (
                        <span className="inline-flex items-center gap-1 text-[9px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-md border border-rose-500/20">
                          <AlertCircle className="w-2.5 h-2.5" />
                          <span>{lang === 'am' ? 'ውድቅ ተደርጓል' : 'Failed'}</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
